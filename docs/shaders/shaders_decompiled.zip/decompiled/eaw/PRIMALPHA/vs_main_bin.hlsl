// vs_1_1 PRIMALPHA::vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float2 m_distanceFadeVals : register(c4);

// inputs: v0=POSITION0, v1=COLOR0, v2=TEXCOORD0
main {
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r0.w = 1 / r0.w;
    r0.w = m_distanceFadeVals.x * r0.w + m_distanceFadeVals.y;
    r0.w = max(r0.w, 0);
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.w = min(r0.w, 1);
    out.POSITION.xyz = r0.xyz;
    out.COLOR0.w = r0.w * in.COLOR0.w;
    out.COLOR0.xyz = in.COLOR0.xyz;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
