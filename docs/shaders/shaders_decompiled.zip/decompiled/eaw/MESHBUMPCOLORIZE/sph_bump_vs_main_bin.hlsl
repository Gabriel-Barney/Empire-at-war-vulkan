// vs_1_1 MESHBUMPCOLORIZE::sph_bump_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphFill[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float3 m_light0ObjVector : register(c21);
uniform float4 m_light0Specular : register(c22);
uniform float4 m_lightScale : register(c23);
uniform float2 m_fogVals : register(c24);
uniform float3 Emissive : register(c25);
uniform float3 Diffuse : register(c26);
uniform float3 Specular : register(c27);
uniform float4 UVOffset : register(c28);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=TANGENT0, v4=BINORMAL0
main {
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r2.x = dot(m_light0ObjVector.xyz, in.TANGENT0.xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r2.y = dot(m_light0ObjVector.xyz, in.BINORMAL0.xyz);
    r0.w = rsqrt(r1.x);
    r2.z = dot(m_light0ObjVector.xyz, in.NORMAL0.xyz);
    r0.xyz = r0.xyz * r0.www;
    r3.x = dot(r2.xyz, r2.xyz);
    r1 = r0.yyyy * m_sphFill[1];
    r0.w = rsqrt(r3.x);
    r1 = m_sphFill[0] * r0.xxxx + r1;
    r2.xyz = r2.xyz * r0.www;
    r1 = m_sphFill[2] * r0.zzzz + r1;
    out.TEXCOORD2.xyz = r2.xyz * 0.5 + 0.5;
    r2 = r1 + m_sphFill[3];
    r0.w = 1;
    r1 = r0.yyyy * m_sphFill[5];
    r3.x = dot(r0, r2);
    r1 = m_sphFill[4] * r0.xxxx + r1;
    r1 = m_sphFill[6] * r0.zzzz + r1;
    r2.x = dot(in.POSITION0, m_world[0]);
    r2.y = dot(in.POSITION0, m_world[1]);
    r2.z = dot(in.POSITION0, m_world[2]);
    r1 = r1 + m_sphFill[7];
    r2.xyz = -r2.xyz + m_eyePos.xyz;
    r3.y = dot(r0, r1);
    r4.x = dot(r2.xyz, r2.xyz);
    r1 = r0.yyyy * m_sphFill[9];
    r2.w = rsqrt(r4.x);
    r1 = m_sphFill[8] * r0.xxxx + r1;
    r2.xyz = r2.xyz * r2.www + m_light0Vector.xyz;
    r1 = m_sphFill[10] * r0.zzzz + r1;
    r4.x = dot(r2.xyz, r2.xyz);
    r1 = r1 + m_sphFill[11];
    r2.w = rsqrt(r4.x);
    r3.z = dot(r0, r1);
    r2.xyz = r2.xyz * r2.www;
    r1.xyz = r3.xyz * Diffuse.xyz;
    r2.x = dot(r0.xyz, r2.xyz);
    r0.xyz = m_lightScale.xyz;
    out.COLOR0.xyz = r1.xyz * r0.xyz + Emissive.xyz;
    r0.w = max(r2.x, 0);
    r0.w = r0.w * r0.w;
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.w = r0.w * r0.w;
    r1.x = dot(r0.xyz, r0.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r1.x);
    r1.w = r1.w * r1.w;
    r0.w = 1 / r0.w;
    r1.xyz = r1.www * m_light0Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.COLOR1.xyz = r1.xyz * Specular.xyz;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r0.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = m_lightScale.w;
    r0.xy = in.TEXCOORD0.xy + UVOffset.xy;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = r0.xy;
    out.TEXCOORD1.xy = r0.xy;
    out.TEXCOORD3.xyz = 0;
}
