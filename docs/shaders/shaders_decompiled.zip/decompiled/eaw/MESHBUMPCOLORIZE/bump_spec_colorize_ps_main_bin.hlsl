// ps_2_0 MESHBUMPCOLORIZE::bump_spec_colorize_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float4 m_lightScale : register(c2);
uniform float3 Diffuse : register(c3);
uniform float3 Specular : register(c4);
uniform float4 Colorization : register(c5);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);

// inputs: v0=COLOR0
main {
    r1 = tex2D(BaseSampler, in.TEXCOORD0);
    r0 = tex2D(NormalSampler, in.TEXCOORD1);
    r2.xyz = Colorization.xyz * r1.xyz + -r1.xyz;
    r1.xyz = r1.www * r2.xyz + r1.xyz;
    r2.xyz = in.TEXCOORD2.xyz + -0.5;
    r2.xyz = r2.xyz + r2.xyz;
    r0.xyz = r0.xyz + -0.5;
    r0.xyz = r0.xyz + r0.xyz;
    r2.x = saturate(dot(r0.xyz, r2.xyz));
    r2.xyz = r2.xxx * Diffuse.xyz;
    r2.xyz = r2.xyz * m_light0Diffuse.xyz;
    r2.xyz = r2.xyz * m_lightScale.xyz + in.COLOR0.xyz;
    r1.xyz = r1.xyz * r2.xyz;
    r1.xyz = r1.xyz + r1.xyz;
    r2.xyz = in.TEXCOORD3.xyz + -0.5;
    r2.xyz = r2.xyz + r2.xyz;
    r0.x = saturate(dot(r0.xyz, r2.xyz));
    r1.w = pow(abs(r0.x), 16);
    r0.xyz = m_light0Specular.xyz;
    r0.xyz = r0.xyz * Specular.xyz;
    r0.xyz = r1.www * r0.xyz;
    r0.xyz = r0.xyz * r0.www + r1.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;
}
