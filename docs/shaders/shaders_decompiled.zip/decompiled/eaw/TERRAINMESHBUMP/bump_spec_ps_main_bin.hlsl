// ps_2_0 TERRAINMESHBUMP::bump_spec_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float3 Diffuse : register(c2);
uniform float3 Specular : register(c3);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);
uniform sampler2d CloudSampler : register(s2);
uniform sampler2d FOWSampler : register(s3);

// inputs: v0=COLOR0
main {
    r3 = tex2D(NormalSampler, in.TEXCOORD1);
    r2 = tex2D(BaseSampler, in.TEXCOORD0);
    r1 = tex2D(CloudSampler, in.TEXCOORD2);
    r0 = tex2D(FOWSampler, in.TEXCOORD3);
    r4.xyz = in.TEXCOORD4.xyz + -0.5;
    r4.xyz = r4.xyz + r4.xyz;
    r3.xyz = r3.xyz + -0.5;
    r3.xyz = r3.xyz + r3.xyz;
    r4.x = dot(r3.xyz, r4.xyz);
    r0.w = r4.x * -0.25;
    r0.w = (r4.x >= 0) ? r4.x : r0.w;
    r4.xyz = r0.www * Diffuse.xyz;
    r4.xyz = r4.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r2.xyz = r2.xyz * r4.xyz;
    r4.xyz = in.TEXCOORD5.xyz + -0.5;
    r4.xyz = r4.xyz + r4.xyz;
    r3.x = saturate(dot(r3.xyz, r4.xyz));
    r0.w = pow(abs(r3.x), 16);
    r3.xyz = m_light0Specular.xyz;
    r3.xyz = r3.xyz * Specular.xyz;
    r3.xyz = r0.www * r3.xyz;
    r3.xyz = r2.www * r3.xyz;
    r3.xyz = r3.xyz + r3.xyz;
    r2.xyz = 2 * r2.xyz + r3.xyz;
    r1.xyz = r1.xyz * r2.xyz;
    r0.xyz = r0.xyz * r1.xyz;
    r0.w = 1;
    out.COLOR0 = r0;
}
