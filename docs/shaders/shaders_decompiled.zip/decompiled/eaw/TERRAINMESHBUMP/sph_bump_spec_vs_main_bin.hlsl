// vs_1_1 TERRAINMESHBUMP::sph_bump_spec_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphFill[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePosObj : register(c19);
uniform float3 m_light0ObjVector : register(c20);
uniform float2 m_fogVals : register(c21);
uniform float4 m_FOWTexU : register(c22);
uniform float4 m_FOWTexV : register(c23);
uniform float4 m_cloudTexU : register(c24);
uniform float4 m_cloudTexV : register(c25);
uniform float3 Emissive : register(c26);
uniform float3 Diffuse : register(c27);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=TANGENT0, v4=BINORMAL0
main {
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.x = dot(m_light0ObjVector.xyz, in.TANGENT0.xyz);
    r0.y = dot(m_light0ObjVector.xyz, in.BINORMAL0.xyz);
    r0.z = dot(m_light0ObjVector.xyz, in.NORMAL0.xyz);
    r1.xyz = -in.POSITION0.xyz + m_eyePosObj.xyz;
    r3.x = dot(r0.xyz, r0.xyz);
    r2.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r3.x);
    r0.w = rsqrt(r2.x);
    r0.xyz = r0.xyz * r1.www;
    r1.xyz = r1.xyz * r0.www + m_light0ObjVector.xyz;
    out.TEXCOORD4.xyz = r0.xyz * 0.5 + 0.5;
    r0.x = dot(r1.xyz, r1.xyz);
    r0.w = rsqrt(r0.x);
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r1.xyz = r1.xyz * r0.www;
    r3.x = dot(r0.xyz, r0.xyz);
    r2.x = dot(r1.xyz, in.TANGENT0.xyz);
    r0.w = rsqrt(r3.x);
    r2.y = dot(r1.xyz, in.BINORMAL0.xyz);
    r0.xyz = r0.xyz * r0.www;
    r2.z = dot(r1.xyz, in.NORMAL0.xyz);
    r1 = r0.yyyy * m_sphFill[1];
    r3.x = dot(r2.xyz, r2.xyz);
    r1 = m_sphFill[0] * r0.xxxx + r1;
    r2.w = rsqrt(r3.x);
    r1 = m_sphFill[2] * r0.zzzz + r1;
    r1 = r1 + m_sphFill[3];
    r0.w = 1;
    r4.xyz = r2.xyz * r2.www;
    r3.x = dot(r0, r1);
    r2 = r0.yyyy * m_sphFill[5];
    r1 = r0.yyyy * m_sphFill[9];
    r2 = m_sphFill[4] * r0.xxxx + r2;
    r1 = m_sphFill[8] * r0.xxxx + r1;
    r2 = m_sphFill[6] * r0.zzzz + r2;
    r1 = m_sphFill[10] * r0.zzzz + r1;
    r2 = r2 + m_sphFill[7];
    r1 = r1 + m_sphFill[11];
    r3.y = dot(r0, r2);
    r3.z = dot(r0, r1);
    out.TEXCOORD5.xyz = r4.xyz * 0.5 + 0.5;
    r0.xyz = Diffuse.xyz;
    out.COLOR0.xyz = r3.xyz * r0.xyz + Emissive.xyz;
    r0.x = dot(in.POSITION0, m_world[0]);
    r0.y = dot(in.POSITION0, m_world[1]);
    r0.z = dot(in.POSITION0, m_world[2]);
    r1.x = dot(in.POSITION0, m_worldViewProj[0]);
    r1.y = dot(in.POSITION0, m_worldViewProj[1]);
    r1.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.w = 1;
    r2.x = dot(r1.xyz, r1.xyz);
    out.TEXCOORD2.x = dot(m_cloudTexU, r0);
    r1.w = rsqrt(r2.x);
    out.TEXCOORD2.y = dot(m_cloudTexV, r0);
    r1.w = 1 / r1.w;
    out.TEXCOORD3.x = dot(m_FOWTexU, r0);
    r1.w = m_fogVals.x * r1.w + m_fogVals.y;
    out.TEXCOORD3.y = dot(m_FOWTexV, r0);
    r0.w = max(r1.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = 1;
    out.COLOR1 = float4(0, 0, 0, 1);
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
    out.TEXCOORD1.xy = in.TEXCOORD0.xy;
}
