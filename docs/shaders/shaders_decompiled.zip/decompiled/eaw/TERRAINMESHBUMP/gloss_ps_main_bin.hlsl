// ps_1_1 TERRAINMESHBUMP::gloss_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d CloudSampler : register(s1);
uniform sampler2d FOWSampler : register(s2);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(CloudSampler, in.TEXCOORD1);
    t2 = tex2D(FOWSampler, in.TEXCOORD2);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r1.xyz = 2 * (t0.www * in.COLOR1.xyz);
    r0.xyz = r1.xyz + r0.xyz;
    r0.xyz = t1.xyz * r0.xyz;
    r0.xyz = t2.xyz * r0.xyz;
    r0.w = 1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
