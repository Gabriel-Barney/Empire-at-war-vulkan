// vs_1_1 TERRAINMESHBUMP::sph_gloss_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float4 m_light0Specular : register(c21);
uniform float2 m_fogVals : register(c22);
uniform float4 m_FOWTexU : register(c23);
uniform float4 m_FOWTexV : register(c24);
uniform float4 m_cloudTexU : register(c25);
uniform float4 m_cloudTexV : register(c26);
uniform float3 Emissive : register(c27);
uniform float3 Diffuse : register(c28);
uniform float3 Specular : register(c29);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r1.xyz = r0.xyz * r0.www;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0 = r1.yyyy * m_sphAll[1];
    r2 = m_sphAll[0] * r1.xxxx + r0;
    r0.x = dot(in.POSITION0, m_world[0]);
    r0.y = dot(in.POSITION0, m_world[1]);
    r0.z = dot(in.POSITION0, m_world[2]);
    r2 = m_sphAll[2] * r1.zzzz + r2;
    r4.xyz = -r0.xyz + m_eyePos.xyz;
    r2 = r2 + m_sphAll[3];
    r3.x = dot(r4.xyz, r4.xyz);
    r1.w = 1;
    r0.w = rsqrt(r3.x);
    r3.x = dot(r1, r2);
    r4.xyz = r4.xyz * r0.www + m_light0Vector.xyz;
    r2 = r1.yyyy * m_sphAll[5];
    r5.x = dot(r4.xyz, r4.xyz);
    r2 = m_sphAll[4] * r1.xxxx + r2;
    r0.w = rsqrt(r5.x);
    r2 = m_sphAll[6] * r1.zzzz + r2;
    r4.xyz = r4.xyz * r0.www;
    r2 = r2 + m_sphAll[7];
    r4.x = dot(r1.xyz, r4.xyz);
    r3.y = dot(r1, r2);
    r0.w = max(r4.x, 0);
    r2 = r1.yyyy * m_sphAll[9];
    r0.w = r0.w * r0.w;
    r2 = m_sphAll[8] * r1.xxxx + r2;
    r0.w = r0.w * r0.w;
    r2 = m_sphAll[10] * r1.zzzz + r2;
    r0.w = r0.w * r0.w;
    r2 = r2 + m_sphAll[11];
    r0.w = r0.w * r0.w;
    r3.z = dot(r1, r2);
    r1.xyz = r0.www * m_light0Specular.xyz;
    r2.xyz = Diffuse.xyz;
    out.COLOR0.xyz = r3.xyz * r2.xyz + Emissive.xyz;
    out.COLOR1.xyz = r1.xyz * Specular.xyz;
    r0.w = 1;
    r1.x = dot(in.POSITION0, m_worldViewProj[0]);
    r1.y = dot(in.POSITION0, m_worldViewProj[1]);
    r1.z = dot(in.POSITION0, m_worldViewProj[2]);
    out.TEXCOORD1.x = dot(m_cloudTexU, r0);
    r2.x = dot(r1.xyz, r1.xyz);
    out.TEXCOORD1.y = dot(m_cloudTexV, r0);
    r1.w = rsqrt(r2.x);
    out.TEXCOORD2.x = dot(m_FOWTexU, r0);
    r1.w = 1 / r1.w;
    out.TEXCOORD2.y = dot(m_FOWTexV, r0);
    r0.w = m_fogVals.x * r1.w + m_fogVals.y;
    out.POSITION.xyz = r1.xyz;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = 1;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
