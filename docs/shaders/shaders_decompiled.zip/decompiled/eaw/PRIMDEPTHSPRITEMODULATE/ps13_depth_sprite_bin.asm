// PRIMDEPTHSPRITEMODULATE :: ps13_depth_sprite_bin  (sha1 c154786be79c)
ps_1_3
    tex t0
    tex t1
    texm3x2pad t2, t1
    texm3x2depth t3, t1
    add r0, v0, t0
// 5 instruction slots used
