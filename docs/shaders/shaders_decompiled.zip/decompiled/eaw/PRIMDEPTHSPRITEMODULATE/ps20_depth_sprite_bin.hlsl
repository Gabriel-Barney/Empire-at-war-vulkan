// ps_2_0 PRIMDEPTHSPRITEMODULATE::ps20_depth_sprite_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d DepthSampler : register(s1);

// inputs: v0=COLOR0
main {
    r1 = tex2D(BaseSampler, in.TEXCOORD0);
    r0 = tex2D(DepthSampler, in.TEXCOORD0);
    r1 = r1 + in.COLOR0;
    out.COLOR0 = r1;
    r1.x = dot(in.TEXCOORD2.xyz, r0.xyz);
    r0.x = dot(in.TEXCOORD1.xyz, r0.xyz);
    r0.w = 1 / r1.x;
    r0.w = r0.x * r0.w;
    out.DEPTH = r0.wwww;
}
