// vs_1_1 MESHADDITIVEOFFSET::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4 m_lightScale : register(c4);
uniform float4 UVOffset : register(c5);
uniform float3 Color : register(c6);

// inputs: v0=POSITION0, v1=TEXCOORD0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    out.POSITION.z = dot(r0, m_worldViewProj[2]);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r0.xyz = m_lightScale.xyz;
    r0.xyz = r0.xyz * Color.xyz;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy + UVOffset.xy;
    out.COLOR0.xyz = r0.xyz * m_lightScale.www;
    out.COLOR0.w = 1;
    out.FOG = 1;
}
