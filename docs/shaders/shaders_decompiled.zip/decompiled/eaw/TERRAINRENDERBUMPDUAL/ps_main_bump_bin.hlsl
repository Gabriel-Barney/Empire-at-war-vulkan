// ps_2_0 TERRAINRENDERBUMPDUAL::ps_main_bump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float4 MaterialDiffuse0 : register(c2);
uniform float4 MaterialDiffuse1 : register(c3);
uniform float4 MaterialSpecular0 : register(c4);
uniform float4 MaterialSpecular1 : register(c5);
uniform sampler2d DiffuseSampler0 : register(s0);
uniform sampler2d DiffuseSampler1 : register(s1);
uniform sampler2d NormalSampler0 : register(s2);
uniform sampler2d NormalSampler1 : register(s3);
uniform sampler2d BlendSampler : register(s4);
uniform sampler2d CloudSampler : register(s5);

// inputs: v0=COLOR0
main {
    r5 = tex2D(NormalSampler0, in.TEXCOORD0);
    r4 = tex2D(DiffuseSampler0, in.TEXCOORD0);
    r1 = tex2D(CloudSampler, in.TEXCOORD3);
    r3 = tex2D(NormalSampler1, in.TEXCOORD1);
    r2 = tex2D(DiffuseSampler1, in.TEXCOORD1);
    r0 = tex2D(BlendSampler, in.TEXCOORD2);
    r6.xyz = in.TEXCOORD5.xyz + -0.5;
    r6.xyz = r6.xyz + r6.xyz;
    r5.xyz = r5.xyz + -0.5;
    r7.xyz = r5.xyz + r5.xyz;
    r0.x = saturate(dot(r7.xyz, r6.xyz));
    r1.w = pow(abs(r0.x), 16);
    r6.xyz = m_light0Specular.xyz;
    r5.xyz = r6.xyz * MaterialSpecular0.xyz;
    r5.xyz = r1.www * r5.xyz;
    r8.xyz = in.TEXCOORD4.xyz + -0.5;
    r8.xyz = r8.xyz + r8.xyz;
    r0.x = saturate(dot(r7.xyz, r8.xyz));
    r7.xyz = r0.xxx * MaterialDiffuse0.xyz;
    r8.xyz = in.COLOR0.xyz * MaterialDiffuse0.xyz;
    r7.xyz = r7.xyz * m_light0Diffuse.xyz + r8.xyz;
    r4.xyz = r4.xyz * r7.xyz;
    r4.xyz = r4.xyz + r4.xyz;
    r4.xyz = r5.xyz * r4.www + r4.xyz;
    r4.xyz = r1.xyz * r4.xyz;
    r5.xyz = in.TEXCOORD7.xyz + -0.5;
    r7.xyz = r5.xyz + r5.xyz;
    r3.xyz = r3.xyz + -0.5;
    r5.xyz = r3.xyz + r3.xyz;
    r0.x = saturate(dot(r5.xyz, r7.xyz));
    r1.w = pow(abs(r0.x), 16);
    r3.xyz = r6.xyz * MaterialSpecular1.xyz;
    r3.xyz = r1.www * r3.xyz;
    r6.xyz = in.TEXCOORD6.xyz + -0.5;
    r6.xyz = r6.xyz + r6.xyz;
    r0.x = saturate(dot(r5.xyz, r6.xyz));
    r5.xyz = r0.xxx * MaterialDiffuse1.xyz;
    r6.xyz = in.COLOR0.xyz * MaterialDiffuse1.xyz;
    r5.xyz = r5.xyz * m_light0Diffuse.xyz + r6.xyz;
    r2.xyz = r2.xyz * r5.xyz;
    r2.xyz = r2.xyz + r2.xyz;
    r2.xyz = r3.xyz * r2.www + r2.xyz;
    r1.xyz = r1.xyz * r2.xyz;
    r1.xyz = r0.yyy * r1.xyz;
    r0.xyz = r0.zzz * r4.xyz + r1.xyz;
    out.COLOR0 = r0;
}
