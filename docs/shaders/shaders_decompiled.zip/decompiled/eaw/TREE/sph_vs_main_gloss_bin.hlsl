// vs_1_1 TREE::sph_vs_main_gloss_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_viewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float4 m_light0Specular : register(c21);
uniform float4 m_lightScale : register(c22);
uniform float2 m_fogVals : register(c23);
uniform float4 m_bendVector : register(c24);
uniform float3 Emissive : register(c25);
uniform float3 Diffuse : register(c26);
uniform float3 Specular : register(c27);
uniform float BendScale : register(c28);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r0.w = in.POSITION0.z * in.POSITION0.z;
    r0.w = r0.w * m_bendVector.w;
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r3.x = dot(in.POSITION0, m_world[0]);
    r1.x = dot(r0.xyz, r0.xyz);
    r3.y = dot(in.POSITION0, m_world[1]);
    r1.w = rsqrt(r1.x);
    r3.z = dot(in.POSITION0, m_world[2]);
    r1.xyz = r0.xyz * r1.www;
    r0.xyz = m_bendVector.xyz;
    r0.xyz = r0.xyz * BendScale.xxx;
    r2 = r1.yyyy * m_sphAll[1];
    r0.xyz = r0.xyz * r0.www + r3.xyz;
    r2 = m_sphAll[0] * r1.xxxx + r2;
    r0.w = 1;
    r2 = m_sphAll[2] * r1.zzzz + r2;
    out.POSITION.w = dot(r0, m_viewProj[3]);
    r3 = r2 + m_sphAll[3];
    r1.w = 1;
    r2 = r1.yyyy * m_sphAll[5];
    r3.x = dot(r1, r3);
    r2 = m_sphAll[4] * r1.xxxx + r2;
    r2 = m_sphAll[6] * r1.zzzz + r2;
    r4.xyz = -r0.xyz + m_eyePos.xyz;
    r2 = r2 + m_sphAll[7];
    r5.x = dot(r4.xyz, r4.xyz);
    r3.y = dot(r1, r2);
    r3.w = rsqrt(r5.x);
    r2 = r1.yyyy * m_sphAll[9];
    r4.xyz = r4.xyz * r3.www + m_light0Vector.xyz;
    r2 = m_sphAll[8] * r1.xxxx + r2;
    r5.x = dot(r4.xyz, r4.xyz);
    r2 = m_sphAll[10] * r1.zzzz + r2;
    r3.w = rsqrt(r5.x);
    r2 = r2 + m_sphAll[11];
    r4.xyz = r4.xyz * r3.www;
    r3.z = dot(r1, r2);
    r2.x = dot(r1.xyz, r4.xyz);
    r1.xyz = r3.xyz * Diffuse.xyz;
    r1.w = max(r2.x, 0);
    r2.xyz = m_lightScale.xyz;
    out.COLOR0.xyz = r1.xyz * r2.xyz + Emissive.xyz;
    r1.w = r1.w * r1.w;
    r1.w = r1.w * r1.w;
    r1.x = dot(r0, m_viewProj[0]);
    r1.y = dot(r0, m_viewProj[1]);
    r1.z = dot(r0, m_viewProj[2]);
    r0.w = r1.w * r1.w;
    r0.x = dot(r1.xyz, r1.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r0.x);
    r0.xyz = r1.www * m_light0Specular.xyz;
    r0.w = 1 / r0.w;
    out.COLOR1.xyz = r0.xyz * Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.POSITION.xyz = r1.xyz;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = m_lightScale.w;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
