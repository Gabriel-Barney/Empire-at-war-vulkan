// ps_1_1 PRIMPARTICLEBUMPALPHA::bump_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 Diffuse : register(c1);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(NormalSampler, in.TEXCOORD1);
    t2 = saturate(float4(in.TEXCOORD2.xyz, 1));
    r0.xyz = saturate(dot((2 * t1.xyz - 1), (2 * t2.xyz - 1)));
    r0.xyz = r0.xyz * Diffuse.xyz;
    r0.xyz = r0.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r0.xyz = 2 * (t0.xyz * r0.xyz);
    r0.w = t0.w * in.COLOR0.w;
    r0.xyz = t1.www * in.COLOR1.xyz + r0.xyz;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
