// vs_1_1 PRIMPARTICLEBUMPALPHA::particle_bump_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphFill[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4x4 m_viewInv : register(c19);   // 3 regs
uniform float4x4 m_worldViewInv : register(c22);   // 3 regs
uniform float4 m_eyePosObj : register(c25);
uniform float3 m_light0ObjVector : register(c26);
uniform float2 m_fogVals : register(c27);
uniform float2 m_distanceFadeVals : register(c28);
uniform float3 Emissive : register(c29);
uniform float4 Diffuse : register(c30);

// inputs: v0=POSITION0, v1=TEXCOORD0, v2=COLOR0
main {
    r0.xyz = in.COLOR0.xyz + -0.5;
    r1.xyz = r0.xyz + r0.xyz;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.x = dot(r1.xyz, m_viewInv[0].xyz);
    r0.y = dot(r1.xyz, m_viewInv[1].xyz);
    r0.z = dot(r1.xyz, m_viewInv[2].xyz);
    r1.x = dot(m_light0ObjVector.xyz, r0.xyz);
    r4.y = m_worldViewInv[1].z;
    r4.z = m_worldViewInv[2].z;
    r4.x = m_worldViewInv[0].z;
    r3.xyz = r0.yzx * r4.zxy;
    r2.xyz = -in.POSITION0.xyz + m_eyePosObj.xyz;
    r3.xyz = r4.yzx * r0.zxy + -r3.xyz;
    r5.x = dot(r2.xyz, r2.xyz);
    r1.y = dot(m_light0ObjVector.xyz, r3.xyz);
    r0.w = rsqrt(r5.x);
    r1.z = dot(m_light0ObjVector.xyz, r4.xyz);
    r2.xyz = r2.xyz * r0.www + m_light0ObjVector.xyz;
    r6.x = dot(r1.xyz, r1.xyz);
    r5.x = dot(r2.xyz, r2.xyz);
    r1.w = rsqrt(r6.x);
    r0.w = rsqrt(r5.x);
    r1.xyz = r1.xyz * r1.www;
    r2.xyz = r2.xyz * r0.www;
    out.TEXCOORD2.xyz = r1.xyz * 0.5 + 0.5;
    r1.x = dot(r2.xyz, r0.xyz);
    r1.z = dot(r2.xyz, r4.xyz);
    r0.x = dot(r4.xyz, m_world[0].xyz);
    r0.y = dot(r4.xyz, m_world[1].xyz);
    r0.z = dot(r4.xyz, m_world[2].xyz);
    r1.y = dot(r2.xyz, r3.xyz);
    r3.x = dot(r0.xyz, r0.xyz);
    r2.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r3.x);
    r0.w = rsqrt(r2.x);
    r0.xyz = r0.xyz * r1.www;
    r2.xyz = r1.xyz * r0.www;
    r1 = r0.yyyy * m_sphFill[1];
    out.TEXCOORD3.xyz = r2.xyz * 0.5 + 0.5;
    r1 = m_sphFill[0] * r0.xxxx + r1;
    r2 = m_sphFill[2] * r0.zzzz + r1;
    r1 = r0.yyyy * m_sphFill[5];
    r2 = r2 + m_sphFill[3];
    r1 = m_sphFill[4] * r0.xxxx + r1;
    r0.w = 1;
    r1 = m_sphFill[6] * r0.zzzz + r1;
    r3.x = dot(r0, r2);
    r1 = r1 + m_sphFill[7];
    r3.y = dot(r0, r1);
    r1 = r0.yyyy * m_sphFill[9];
    r1 = m_sphFill[8] * r0.xxxx + r1;
    r2.x = dot(in.POSITION0, m_worldViewProj[0]);
    r2.y = dot(in.POSITION0, m_worldViewProj[1]);
    r2.z = dot(in.POSITION0, m_worldViewProj[2]);
    r1 = m_sphFill[10] * r0.zzzz + r1;
    r4.x = dot(r2.xyz, r2.xyz);
    r1 = r1 + m_sphFill[11];
    r2.w = rsqrt(r4.x);
    r3.z = dot(r0, r1);
    r0.w = 1 / r2.w;
    r0.xyz = Diffuse.xyz;
    out.COLOR0.xyz = r3.xyz * r0.xyz + Emissive.xyz;
    r1.w = m_distanceFadeVals.x * r0.w + m_distanceFadeVals.y;
    out.POSITION.xyz = r2.xyz;
    r1.w = max(r1.w, 0);
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    r1.w = min(r1.w, 1);
    out.COLOR0.w = r1.w * in.COLOR0.w;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR1 = float4(0, 0, 0, 1);
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
    out.TEXCOORD1.xy = in.TEXCOORD0.xy;
}
