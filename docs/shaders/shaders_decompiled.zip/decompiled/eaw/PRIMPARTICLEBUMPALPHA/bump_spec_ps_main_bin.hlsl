// ps_1_4 PRIMPARTICLEBUMPALPHA::bump_spec_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float4 Diffuse : register(c2);
uniform float4 Specular : register(c3);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);

main {
    r0.xyz = in.TEXCOORD2.xyz;
    r1 = tex2D(NormalSampler, in.TEXCOORD1.xyz);
    r2.xyz = in.TEXCOORD3.xyz;
    r3.xyz = m_light0Specular.xyz * Specular.xyz;
    r2.w = saturate(dot((2 * r1.xyz - 1), (2 * r2.xyz - 1)));
    r4.w = r2.w * r2.w;
    r4.w = r4.w * r4.w;
    r2.w = r2.w * r4.w;
    r2.xyz = r2.www * r3.xyz;
    r3.xyz = r0.xyz;
    r4.x = r1.w;
    // phase (ps_1_4: second texture-addressing phase)
    r0 = tex2D(BaseSampler, in.TEXCOORD0.xyz);
    r4.w = r4.x;
    r1.w = saturate(dot((2 * r1.xyz - 1), (2 * r3.xyz - 1)));
    r1.xyz = r1.www * Diffuse.xyz;
    r1.xyz = r1.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r1.xyz = r0.xyz * r1.xyz;
    r0.w = r0.w * in.COLOR0.w;
    r0.xyz = r4.www * r2.xyz + (2 * r1.xyz);
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
