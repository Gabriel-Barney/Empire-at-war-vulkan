// vs_1_1 MESHSHADOWVOLUME::vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float3 m_light0ObjVector : register(c4);
uniform float4 DebugColor : register(c5);

// CPU preshader: computes shader constants c# from effect parameters
cpu: c6.xyz = m_extrusion.x * m_light0ObjVector.xyz;

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.x = dot(in.NORMAL0.xyz, m_light0ObjVector.xyz);
    r0.w = (r0.x < 0) ? 1 : 0;
    r1 = r0.wwww * DebugColor;
    r0.xyz = r0.www * -c6.xyz + in.POSITION0.xyz;
    r2 = DebugColor;
    out.COLOR0 = r1 * -0.7 + r2;
    r0.w = 1;
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    out.POSITION.z = dot(r0, m_worldViewProj[2]);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
}
