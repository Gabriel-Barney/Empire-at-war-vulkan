// ps_1_1 BATCHMESHGLOSS::ps_main_1_1  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d FOWSampler : register(s1);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(FOWSampler, in.TEXCOORD1);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r0.xyz = t0.www * in.COLOR1.xyz + r0.xyz;
    r0.xyz = t1.xyz * r0.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
