// ps_1_1 SCENEBLOOM::ps_combine_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float BloomStrength : register(c0);
uniform sampler2d SceneSampler0 : register(s0);

main {
    t0 = tex2D(SceneSampler0, in.TEXCOORD0);
    r0 = dot(float3(1, 0, 0), BloomStrength.xyz);
    r0 = t0 * r0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
