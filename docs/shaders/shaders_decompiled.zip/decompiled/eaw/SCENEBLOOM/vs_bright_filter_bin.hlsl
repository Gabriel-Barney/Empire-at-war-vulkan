// vs_1_1 SCENEBLOOM::vs_bright_filter_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_resolutionConstants : register(c0);

// inputs: v0=POSITION0
main {
    r0.xy = float2(0.5, -0.5);
    r0.xy = in.POSITION0.xy * r0.xy + m_resolutionConstants.zw;
    out.TEXCOORD0.xy = r0.xy + 0.5;
    out.POSITION = in.POSITION0.xyxx * float4(1, 1, 0, 0) + float4(0, 0, 0.5, 1);
    out.FOG = 1;
}
