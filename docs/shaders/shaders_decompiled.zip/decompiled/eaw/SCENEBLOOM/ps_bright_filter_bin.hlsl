// ps_1_3 SCENEBLOOM::ps_bright_filter_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float BloomCutoff : register(c0);
uniform sampler2d SceneSampler0 : register(s0);

main {
    t0 = tex2D(SceneSampler0, in.TEXCOORD0);
    r1 = t0 * t0;
    r1 = r1 * r1;
    r1 = t0 * r1;
    t1 = dot(t0.xyz, float3(0.299, 0.587, 0.114));
    t2 = dot(float3(1, 0, 0), BloomCutoff.xyz);
    t1.w = -t1.w + t2.w;
    r0.w = t1.w * -1 + 0.5;
    r0 = (r0.wwww > 0.5) ? t0 : r1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
