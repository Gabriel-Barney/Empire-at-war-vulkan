// vs_1_1 SCENEBLOOM::vs_bloom_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_resolutionConstants : register(c0);
uniform float BloomIteration : register(c1);
uniform float BloomSize : register(c2);

// inputs: v0=POSITION0
main {
    r0.w = BloomIteration.x + BloomIteration.x;
    r0.xy = float2(0.5, -0.5);
    r0.xy = in.POSITION0.xy * r0.xy + m_resolutionConstants.zw;
    r2.xy = r0.ww * m_resolutionConstants.zw + m_resolutionConstants.zw;
    r1.xy = r0.xy + 0.5;
    out.TEXCOORD0.xy = BloomSize.xx * r2.xy + r1.xy;
    r0.xy = r2.xy * BloomSize.xx;
    out.TEXCOORD1.xy = BloomSize.xx * -r2.xy + r1.xy;
    r0.zw = -r0.yx;
    out.TEXCOORD2.xy = r1.xy + r0.xz;
    out.TEXCOORD3.xy = r1.xy + r0.wy;
    out.POSITION = in.POSITION0.xyxx * float4(1, 1, 0, 0) + float4(0, 0, 0.5, 1);
    out.FOG = 1;
}
