// ps_1_1 SCENEBLOOM::ps_bloom_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d SceneSampler0 : register(s0);
uniform sampler2d SceneSampler1 : register(s1);
uniform sampler2d SceneSampler2 : register(s2);
uniform sampler2d SceneSampler3 : register(s3);

main {
    t0 = tex2D(SceneSampler0, in.TEXCOORD0);
    t1 = tex2D(SceneSampler1, in.TEXCOORD1);
    t2 = tex2D(SceneSampler2, in.TEXCOORD2);
    t3 = tex2D(SceneSampler3, in.TEXCOORD3);
    r0 = t0 + t1;
    r0 = t2 + r0;
    r0 = t3 + r0;
    r0 = r0 * 0.25;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
