// vs_1_1 TERRAINWATER::t1.t1_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_world : register(c0);   // 4 regs
uniform float4x4 m_worldViewProj : register(c4);   // 4 regs
uniform float2 m_fogVals : register(c8);
uniform float4 m_FOWTexU : register(c9);
uniform float4 m_FOWTexV : register(c10);
uniform float4 Bump0TexU : register(c11);
uniform float4 Bump0TexV : register(c12);
uniform float4 WaterColor : register(c13);

// inputs: v0=POSITION0, v1=COLOR0
main {
    r2 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r0.w = dot(r2, m_worldViewProj[3]);
    r1.w = 1 / r0.w;
    r0.x = dot(r2, m_worldViewProj[0]);
    r0.y = dot(r2, m_worldViewProj[1]);
    r1.xy = r0.xy * r1.ww + 1;
    out.TEXCOORD1.x = r1.x * 0.5;
    out.TEXCOORD1.y = r1.y * -0.5 + 1;
    r1.x = dot(r2, m_world[0]);
    r1.y = dot(r2, m_world[1]);
    r1.z = dot(r2, m_world[2]);
    r1.w = dot(r2, m_world[3]);
    r0.z = dot(r2, m_worldViewProj[2]);
    out.TEXCOORD0.x = dot(Bump0TexU, r1);
    out.TEXCOORD0.y = dot(Bump0TexV, r1);
    out.TEXCOORD2.x = dot(m_FOWTexU, r1);
    out.TEXCOORD2.y = dot(m_FOWTexV, r1);
    r1.x = dot(r0.xyz, r0.xyz);
    r1.w = in.COLOR0.w * WaterColor.w;
    r2.w = rsqrt(r1.x);
    r1.xyz = WaterColor.xyz;
    r2.w = 1 / r2.w;
    out.COLOR0 = r1 * float4(0.7, 0.7, 0.7, 0.95);
    r1.w = m_fogVals.x * r2.w + m_fogVals.y;
    out.POSITION = r0;
    r0.w = max(r1.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR1 = 0;
}
