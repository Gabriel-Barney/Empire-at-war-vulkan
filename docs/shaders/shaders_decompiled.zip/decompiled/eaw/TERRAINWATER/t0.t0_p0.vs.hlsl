// vs_1_1 TERRAINWATER::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_world : register(c0);   // 4 regs
uniform float4x4 m_worldViewProj : register(c4);   // 4 regs
uniform float4x4 m_texOffset : register(c8);   // 4 regs
uniform float4 m_eyePos : register(c12);
uniform float4 m_light0Vector : register(c13);
uniform float2 m_fogVals : register(c14);
uniform float4 m_FOWTexU : register(c15);
uniform float4 m_FOWTexV : register(c16);
uniform float4 BaseTexU : register(c17);
uniform float4 BaseTexV : register(c18);
uniform float4 Bump0TexU : register(c19);
uniform float4 Bump0TexV : register(c20);
uniform float4 Bump1TexU : register(c21);
uniform float4 Bump1TexV : register(c22);

// inputs: v0=POSITION0, v1=COLOR0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r1.w = dot(r0, m_world[3]);
    r1.x = dot(r0, m_world[0]);
    r1.y = dot(r0, m_world[1]);
    r1.z = dot(r0, m_world[2]);
    out.TEXCOORD0.x = dot(Bump0TexU, r1);
    out.TEXCOORD0.y = dot(Bump0TexV, r1);
    out.TEXCOORD1.y = dot(Bump1TexU, r1);
    out.TEXCOORD1.x = dot(Bump1TexV, r1);
    r4.xy = float2(1, 0);
    r2.xyz = r4.xxy * BaseTexU.xyx;
    out.TEXCOORD4.x = dot(m_FOWTexU, r1);
    r2.x = dot(r2.xyz, r2.xyz);
    out.TEXCOORD4.y = dot(m_FOWTexV, r1);
    r1.w = rsqrt(r2.x);
    r2.yzw = -r1.xzy + m_eyePos.xzy;
    r3.xy = r1.ww * BaseTexU.xy;
    r3.z = 0;
    r4.xyz = r4.xxy * BaseTexV.xyx;
    r1.x = dot(m_light0Vector.xyz, r3.xyz);
    r4.x = dot(r4.xyz, r4.xyz);
    r2.x = dot(r2.ywz, r3.xyz);
    r1.w = rsqrt(r4.x);
    r3.xy = r1.ww * BaseTexV.xy;
    r3.z = 0;
    r1.y = dot(m_light0Vector.xyz, r3.xyz);
    r1.z = m_light0Vector.z;
    r2.y = dot(r2.ywz, r3.xyz);
    r3.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r3.x);
    r3.xyz = r1.xyz * r1.www;
    r1.x = dot(r0, m_worldViewProj[0]);
    r1.y = dot(r0, m_worldViewProj[1]);
    r1.z = dot(r0, m_worldViewProj[2]);
    out.TEXCOORD5.xyz = r3.xyz * 0.5 + 0.5;
    r4.x = dot(r1.xyz, r1.xyz);
    r3.x = dot(r2.xyz, r2.xyz);
    r1.w = rsqrt(r4.x);
    r2.w = rsqrt(r3.x);
    r1.w = 1 / r1.w;
    out.TEXCOORD6.xyz = r2.xyz * r2.www;
    r2.w = m_fogVals.x * r1.w + m_fogVals.y;
    r1.w = dot(r0, m_worldViewProj[3]);
    r0.w = max(r2.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.POSITION = r1;
    r0.x = dot(r1, m_texOffset[0]);
    r0.y = dot(r1, m_texOffset[1]);
    r0.z = dot(r1, m_texOffset[2]);
    r0.w = dot(r1, m_texOffset[3]);
    out.TEXCOORD2 = r0;
    out.TEXCOORD3 = r0;
    out.COLOR0 = in.COLOR0;
    out.COLOR1 = 0;
}
