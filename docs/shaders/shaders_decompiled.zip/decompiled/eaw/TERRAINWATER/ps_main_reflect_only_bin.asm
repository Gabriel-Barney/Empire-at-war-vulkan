// TERRAINWATER :: ps_main_reflect_only_bin  (sha1 cc8a94960c3a)
ps_1_1
    tex t0
    texbem t1, t0
    tex t2
    mad r0, v0, t1, v1
    mul r0.xyz, r0, t2
// 5 instruction slots used
