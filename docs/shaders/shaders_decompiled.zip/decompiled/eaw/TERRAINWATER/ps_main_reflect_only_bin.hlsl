// ps_1_1 TERRAINWATER::ps_main_reflect_only_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)

main {
    t0 = tex2D(sampler0, in.TEXCOORD0);
    t1 = tex2D(sampler1, in.TEXCOORD1.xy + bumpEnvMat1 * t0.xy);
    t2 = tex2D(sampler2, in.TEXCOORD2);
    r0 = in.COLOR0 * t1 + in.COLOR1;
    r0.xyz = r0.xyz * t2.xyz;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
