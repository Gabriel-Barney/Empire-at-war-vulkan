// ps_2_0 TERRAINWATER::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 WaterReflectC : register(c0);
uniform float4 WaterRefractC : register(c1);
uniform float2 ReflectionDistortionScale : register(c2);
uniform float2 RefractionDistortionScale : register(c3);
uniform sampler2d Bump0Sampler : register(s0);
uniform sampler2d Bump1Sampler : register(s1);
uniform sampler2d ReflectionSampler : register(s2);
uniform sampler2d RefractionSampler : register(s3);
uniform sampler2d FOWSampler : register(s4);
uniform samplercube SkyCubeSampler : register(s5);

// inputs: v0=COLOR0
main {
    r1 = tex2D(Bump1Sampler, in.TEXCOORD1);
    r0 = tex2D(Bump0Sampler, in.TEXCOORD0);
    r1.xyz = r1.xyz + -0.5;
    r1.xyz = r1.xyz + r1.xyz;
    r0.xyz = r0.xyz + -0.5;
    r0.xyz = 2 * r0.xyz + r1.xyz;
    r0.w = r0.z * 15;
    r1.xyz = r0.xyz * float3(1, 1, 15);
    r1.w = r0.x * r1.x;
    r1.w = r0.y * r1.y + r1.w;
    r0.w = r0.w * r1.z + r1.w;
    r0.w = rsqrt(r0.w);
    r1.xyz = r1.xyz * r0.www;
    r2.x = dot(in.TEXCOORD6.xyz, r1.xyz);
    r0.w = r2.x + r2.x;
    r1.xyz = r0.www * r1.xyz + -in.TEXCOORD6.xyz;
    r2.xy = r0.xy * ReflectionDistortionScale.xy;
    r0.xy = r0.xy * RefractionDistortionScale.xy;
    r2.xy = r2.xy * 200 + in.TEXCOORD2.xy;
    r2.zw = in.TEXCOORD2.zw;
    r0.xy = r0.xy * 200 + in.TEXCOORD3.xy;
    r0.zw = in.TEXCOORD3.zw;
    r1 = texCUBE(SkyCubeSampler, r1);
    r3 = tex2Dproj(ReflectionSampler, r2);
    r2 = tex2Dproj(RefractionSampler, r0);
    r0 = tex2D(FOWSampler, in.TEXCOORD4);
    r3.xyz = r3.xyz * WaterReflectC.xyz;
    r2.xyz = WaterRefractC.xyz * r2.xyz + r3.xyz;
    r1.xyz = r1.xyz * r2.xyz;
    r0.xyz = r0.xyz * r1.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;
}
