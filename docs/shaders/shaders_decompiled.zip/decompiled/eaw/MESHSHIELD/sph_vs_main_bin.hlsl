// vs_1_1 MESHSHIELD::sph_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float m_time : register(c4);
uniform float4 Color : register(c5);
uniform float EdgeBrightness : register(c6);
uniform float BaseUVScale : register(c7);
uniform float WaveUVScale : register(c8);
uniform float DistortUVScale : register(c9);
uniform float BaseUVScrollRate : register(c10);
uniform float WaveUVScrollRate : register(c11);
uniform float DistortUVScrollRate : register(c12);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=COLOR0
main {
    out.POSITION.x = dot(in.POSITION0, m_worldViewProj[0]);
    out.POSITION.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.w = in.NORMAL0.z + EdgeBrightness.x;
    out.POSITION.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.w = max(r0.w, 0);
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.w = min(r0.w, 1);
    r0 = r0.wwww * in.COLOR0;
    r1.xy = in.TEXCOORD0.xy * BaseUVScale.xx;
    out.COLOR0 = r0 * Color;
    r0.w = m_time.x;
    r1.z = r0.w * BaseUVScrollRate.x + r1.y;
    out.TEXCOORD0.xy = r1.xz;
    r1.xy = in.TEXCOORD0.xy * DistortUVScale.xx;
    r1.z = r0.w * DistortUVScrollRate.x + r1.y;
    r0.xy = in.TEXCOORD0.xy * WaveUVScale.xx;
    out.TEXCOORD1.xy = r1.xz;
    r0.z = r0.w * WaveUVScrollRate.x + r0.y;
    out.TEXCOORD2.xy = r0.xz;
    out.FOG = 1;
}
