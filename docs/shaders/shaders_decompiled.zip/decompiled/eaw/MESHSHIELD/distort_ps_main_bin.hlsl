// ps_2_0 MESHSHIELD::distort_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d WaveSampler : register(s1);
uniform sampler2d DistortionSampler : register(s2);

// inputs: v0=COLOR0
main {
    r0 = tex2D(DistortionSampler, in.TEXCOORD2);
    r0.xy = r0.xy * 0.25 + in.TEXCOORD0.xy;
    r0 = tex2D(BaseSampler, r0);
    r1 = tex2D(WaveSampler, in.TEXCOORD1);
    r0 = r0 * r1;
    r0 = r0 * in.COLOR0;
    out.COLOR0 = r0;
}
