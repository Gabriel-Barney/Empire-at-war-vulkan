// vs_1_1 MESHCOLLISION::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4 m_lightScale : register(c4);
uniform float2 m_fogVals : register(c5);
uniform float4 Color : register(c6);

// inputs: v0=POSITION0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r1.x = dot(r0, m_worldViewProj[0]);
    r1.y = dot(r0, m_worldViewProj[1]);
    r1.z = dot(r0, m_worldViewProj[2]);
    r2.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r2.x);
    r1.w = 1 / r1.w;
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r1.w = m_fogVals.x * r1.w + m_fogVals.y;
    r0 = Color;
    out.COLOR0 = r0 * m_lightScale;
    r0.w = max(r1.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
}
