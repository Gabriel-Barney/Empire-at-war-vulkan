// vs_1_1 RSKINOCCLUDEDUNIT::vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x3 m_skinMatrixArray[24] : register(c0);   // 72 regs
uniform float4x4 m_viewProj : register(c72);   // 4 regs
uniform float2 m_fogVals : register(c76);

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.w = (in.NORMAL0.w < -in.NORMAL0.w) ? 1 : 0;
    r3.y = frac(in.NORMAL0.w);
    r1.w = r3.y;
    r2.w = -r1.w + in.NORMAL0.w;
    r1.w = (-r1.w < r1.w) ? 1 : 0;
    r0.w = r0.w * r1.w + r2.w;
    r0.w = r0.w * 3;
    a0.x = (int)r0.w;   // vs_1_1 mov to a0 truncates toward zero
    r0.x = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x]);
    r0.y = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 1]);
    r0.z = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 2]);
    r0.w = 1;
    r1.x = dot(r0, m_viewProj[0]);
    r1.y = dot(r0, m_viewProj[1]);
    r1.z = dot(r0, m_viewProj[2]);
    r2.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r2.x);
    r1.w = 1 / r1.w;
    r1.w = m_fogVals.x * r1.w + m_fogVals.y;
    out.POSITION.w = dot(r0, m_viewProj[3]);
    r0.w = max(r1.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
}
