// vs_1_1 RSKINOCCLUDEDUNIT::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c72);   // 4 regs
uniform float2 m_fogVals : register(c76);

// inputs: v0=POSITION0
main {
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r0.w = 1 / r0.w;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r0.xyz;
    out.FOG = min(r0.wwww, 1);
}
