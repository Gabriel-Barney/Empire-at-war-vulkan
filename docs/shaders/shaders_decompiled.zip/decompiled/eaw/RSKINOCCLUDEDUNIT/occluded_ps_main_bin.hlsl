// ps_1_1 RSKINOCCLUDEDUNIT::occluded_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 Color : register(c0);

main {
    r0 = Color;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
