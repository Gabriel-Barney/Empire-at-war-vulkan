// ps_1_1 BATCHMESHALPHA::alpha_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d FOWSampler : register(s1);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(FOWSampler, in.TEXCOORD1);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r0.xyz = r0.xyz + in.COLOR1.xyz;
    r0.w = t0.w * in.COLOR0.w;
    r0.xyz = t1.xyz * r0.xyz;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
