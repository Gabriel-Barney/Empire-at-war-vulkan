// vs_1_1 NEBULA::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4x4 m_world : register(c4);   // 3 regs
uniform float4x4 m_worldView : register(c7);   // 3 regs
uniform float4 m_lightScale : register(c10);
uniform float m_time : register(c11);
uniform float2 UVScrollRate : register(c12);
uniform float DistortionScale : register(c13);
uniform float SFreq : register(c14);
uniform float TFreq : register(c15);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=COLOR0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r2.w = dot(r0, m_world[0]);
    r1.w = m_time.x;
    r3.w = r1.w * TFreq.x;
    r4.w = SFreq.x * r2.w + r3.w;
    r5.y = frac(r4.w);
    r2.w = r5.y;
    r4.w = r2.w * 0.999493 + 0.25;
    r5.y = frac(r4.w);
    r2.w = r5.y;
    r2.w = r2.w * 6.283185 + -3.141593;
    r2.w = r2.w * r2.w;
    r4.w = r2.w * -2.523985e-07 + 2.47609e-05;
    r4.w = r2.w * r4.w + -0.00138884;
    r4.w = r2.w * r4.w + 0.04166664;
    r4.w = r2.w * r4.w + -0.5;
    r1.x = r2.w * r4.w + 1;
    r2.w = dot(r0, m_world[1]);
    r0.w = dot(r0, m_world[2]);
    r2.w = SFreq.x * r2.w + r3.w;
    r3.w = SFreq.x * r0.w + r3.w;
    r5.y = frac(r2.w);
    r0.w = r5.y;
    r5.y = frac(r3.w);
    r2.w = r5.y;
    r0.w = r0.w * 0.999493 + 0.25;
    r3.w = r2.w * 0.999493 + 0.25;
    r5.y = frac(r0.w);
    r2.w = r5.y;
    r5.y = frac(r3.w);
    r0.w = r5.y;
    r2.w = r2.w * 6.283185 + -3.141593;
    r0.w = r0.w * 6.283185 + -3.141593;
    r3.w = r2.w * r2.w;
    r0.w = r0.w * r0.w;
    r4.w = r3.w * -2.523985e-07 + 2.47609e-05;
    r2.w = r0.w * -2.523985e-07 + 2.47609e-05;
    r4.w = r3.w * r4.w + -0.00138884;
    r2.w = r0.w * r2.w + -0.00138884;
    r4.w = r3.w * r4.w + 0.04166664;
    r2.w = r0.w * r2.w + 0.04166664;
    r4.w = r3.w * r4.w + -0.5;
    r2.w = r0.w * r2.w + -0.5;
    r1.y = r3.w * r4.w + 1;
    r1.z = r0.w * r2.w + 1;
    r0.xyz = DistortionScale.xxx * r1.xyz + in.POSITION0.xyz;
    r0.w = 1;
    r1.x = dot(in.NORMAL0.xyz, m_worldView[0].xyz);
    r1.y = dot(in.NORMAL0.xyz, m_worldView[1].xyz);
    r1.z = dot(in.NORMAL0.xyz, m_worldView[2].xyz);
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    r1.x = dot(r1.xyz, r1.xyz);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    r2.w = rsqrt(r1.x);
    out.POSITION.z = dot(r0, m_worldViewProj[2]);
    r2.w = r1.z * r2.w;
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r0.w = r2.w * r2.w;
    r1.xy = r1.ww * UVScrollRate.xy;
    r0.w = r0.w * r0.w;
    r0.w = r0.w * r0.w;
    r0.xyz = in.COLOR0.xyz * m_lightScale.xyz;
    r2.x = 2 * r0.w + 0.09999999;
    r0.xyz = r0.xyz * m_lightScale.www;
    out.TEXCOORD0.xy = r1.xy * 3 + in.TEXCOORD0.xy;
    out.COLOR0.xyz = r2.xxx * r0.xyz;
    out.COLOR0.w = r2.x;
    out.FOG = 1;
}
