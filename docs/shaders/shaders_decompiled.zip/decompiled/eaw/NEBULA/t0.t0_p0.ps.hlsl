// ps_1_1 NEBULA::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    r0 = t0 * in.COLOR0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
