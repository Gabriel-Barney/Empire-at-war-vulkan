// vs_1_1 GRASS::max_grass_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_world : register(c0);   // 4 regs
uniform float4x4 m_viewProj : register(c4);   // 4 regs
uniform float4 m_lightScale : register(c12);
uniform float2 m_fogVals : register(c13);
uniform float2 m_distanceFadeVals : register(c14);
uniform float4 m_FOWTexU : register(c15);
uniform float4 m_FOWTexV : register(c16);
uniform float3 Emissive : register(c17);
uniform float4 Diffuse : register(c18);

// CPU preshader: computes shader constants c# from effect parameters
cpu: r0.w = m_windGrassVector.w * BendScale.x;
cpu: r1.w = r0.w * (0.0875);
cpu: r0.w = r1.w + (0.125);
cpu: c8.x = r0.w * m_time.x;
cpu: r1.x = m_world[0].z;
cpu: r1.y = m_world[1].z;
cpu: r1.z = m_world[2].z;
cpu: r0.w = dot(r1.xyz, r1.xyz);
cpu: r1.w = rsq(r0.w);
cpu: r0.xyz = r1.w * r1.xyz;
cpu: r2.xyzw = r0.x * m_sphAll[0].xyzw;
cpu: r3.xyzw = r0.y * m_sphAll[1].xyzw;
cpu: r1.xyzw = r2.xyzw + r3.xyzw;
cpu: r3.xyzw = r0.z * m_sphAll[2].xyzw;
cpu: r2.xyzw = r1.xyzw + r3.xyzw;
cpu: r1.xyzw = r2.xyzw + m_sphAll[3].xyzw;
cpu: r0.w = (1);
cpu: c10.x = dot(r0.xyzw, r1.xyzw);
cpu: r2.xyzw = r0.x * m_sphAll[4].xyzw;
cpu: r3.xyzw = r0.y * m_sphAll[5].xyzw;
cpu: r1.xyzw = r2.xyzw + r3.xyzw;
cpu: r3.xyzw = r0.z * m_sphAll[6].xyzw;
cpu: r2.xyzw = r1.xyzw + r3.xyzw;
cpu: r1.xyzw = r2.xyzw + m_sphAll[7].xyzw;
cpu: c10.y = dot(r0.xyzw, r1.xyzw);
cpu: r2.xyzw = r0.x * m_sphAll[8].xyzw;
cpu: r3.xyzw = r0.y * m_sphAll[9].xyzw;
cpu: r1.xyzw = r2.xyzw + r3.xyzw;
cpu: r3.xyzw = r0.z * m_sphAll[10].xyzw;
cpu: r2.xyzw = r1.xyzw + r3.xyzw;
cpu: r1.xyzw = r2.xyzw + m_sphAll[11].xyzw;
cpu: c10.z = dot(r0.xyzw, r1.xyzw);
cpu: r0.xyz = -Diffuse.xyz;
cpu: c9.xyz = r0.xyz + Diffuse1.xyz;
cpu: c11.x = m_lightScale.w * Diffuse.w;

// inputs: v0=POSITION0, v1=TEXCOORD0
main {
    r0.z = 0.05;
    r0.w = in.POSITION0.x * r0.z + c8.x;
    r1.w = in.POSITION0.y * 0.05 + r0.w;
    r4.y = frac(r1.w);
    r0.w = r4.y;
    r1.w = r0.w * 0.999493 + 0.25;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy * 0.0002441406;
    r4.y = frac(r1.w);
    r0.w = r4.y;
    r0.x = dot(in.POSITION0, m_world[0]);
    r0.w = r0.w * 6.283185 + -3.141593;
    r0.y = dot(in.POSITION0, m_world[1]);
    r1.w = r0.w * r0.w;
    r0.z = dot(in.POSITION0, m_world[2]);
    r2.w = r1.w * -2.523985e-07 + 2.47609e-05;
    r0.w = dot(in.POSITION0, m_world[3]);
    r2.w = r1.w * r2.w + -0.00138884;
    out.TEXCOORD1.x = dot(m_FOWTexU, r0);
    r2.w = r1.w * r2.w + 0.04166664;
    out.TEXCOORD1.y = dot(m_FOWTexV, r0);
    r0.w = r1.w * r2.w + -0.5;
    out.POSITION.w = dot(in.POSITION0, m_viewProj[3]);
    r0.w = r1.w * r0.w + 1;
    r0.w = r0.w * 0.5 + 0.5;
    r0.x = dot(in.POSITION0, m_viewProj[0]);
    r0.y = dot(in.POSITION0, m_viewProj[1]);
    r0.z = dot(in.POSITION0, m_viewProj[2]);
    r1.xyz = c9.xyz;
    r1.xyz = r0.www * r1.xyz + Diffuse.xyz;
    r3.x = dot(r0.xyz, r0.xyz);
    r2.xyz = r1.xyz * m_lightScale.xyz;
    r0.w = rsqrt(r3.x);
    r1.xyz = c10.xyz;
    out.COLOR0.xyz = r1.xyz * r2.xyz + Emissive.xyz;
    r0.w = 1 / r0.w;
    out.POSITION.xyz = r0.xyz;
    r1.w = m_distanceFadeVals.x * r0.w + m_distanceFadeVals.y;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    r1.w = max(r1.w, 0);
    r1.w = min(r1.w, 1);
    r0.w = max(r0.w, 0);
    out.COLOR0.w = r1.w * c11.x;
    out.FOG = min(r0.wwww, 1);
}
