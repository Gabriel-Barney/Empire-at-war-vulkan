// ps_2_0 GRASS::grass_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d FOWSampler : register(s1);

// inputs: v0=COLOR0
main {
    r1 = tex2D(FOWSampler, in.TEXCOORD1);
    r0 = tex2D(BaseSampler, in.TEXCOORD0);
    r0.xyz = r1.xyz * r0.xyz;
    r0.xyz = r0.xyz * in.COLOR0.xyz;
    r0.w = r0.w * in.COLOR0.w;
    r0.xyz = r0.xyz + r0.xyz;
    out.COLOR0 = r0;
}
