// vs_1_1 RSKINSHADOWVOLUME::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c72);   // 4 regs
uniform float3 m_light0ObjVector : register(c76);
uniform float4 DebugColor : register(c77);

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.x = dot(in.NORMAL0.xyz, in.NORMAL0.xyz);
    r0.w = rsqrt(r0.x);
    r0.xyz = r0.www * in.NORMAL0.xyz;
    r0.x = dot(r0.xyz, m_light0ObjVector.xyz);
    r0.w = (r0.x < 0) ? 1 : 0;
    r0 = r0.wwww * DebugColor;
    r1.z = -0.7;
    out.COLOR0 = r0 * r1.zzzz + DebugColor;
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    out.POSITION.z = dot(r0, m_worldViewProj[2]);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
}
