// ps_1_1 RSKINSHADOWVOLUME::ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):

main {
    r0 = in.COLOR0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
