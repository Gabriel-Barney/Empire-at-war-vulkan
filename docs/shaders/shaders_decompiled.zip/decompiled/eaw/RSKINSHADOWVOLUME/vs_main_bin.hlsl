// vs_1_1 RSKINSHADOWVOLUME::vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x3 m_skinMatrixArray[24] : register(c0);   // 72 regs
uniform float4x4 m_viewProj : register(c72);   // 4 regs
uniform float4 m_light0Vector : register(c76);
uniform float m_extrusion : register(c77);
uniform float4 DebugColor : register(c78);

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.w = (in.NORMAL0.w < -in.NORMAL0.w) ? 1 : 0;
    r4.y = frac(in.NORMAL0.w);
    r1.w = r4.y;
    r2.w = -r1.w + in.NORMAL0.w;
    r1.w = (-r1.w < r1.w) ? 1 : 0;
    r0.w = r0.w * r1.w + r2.w;
    r3.w = r0.w * 3;
    r1.x = dot(in.NORMAL0.xyz, in.NORMAL0.xyz);
    r2.xyz = m_light0Vector.xyz;
    a0.x = (int)r3.w;   // vs_1_1 mov to a0 truncates toward zero
    r0.xyz = r2.yyy * m_skinMatrixArray.reg[a0.x + 1].xyz;
    r0.w = rsqrt(r1.x);
    r1.xyz = r2.xxx * m_skinMatrixArray.reg[a0.x].xyz + r0.xyz;
    r0.xyz = r0.www * in.NORMAL0.xyz;
    r1.xyz = r2.zzz * m_skinMatrixArray.reg[a0.x + 2].xyz + r1.xyz;
    r0.x = dot(r0.xyz, r1.xyz);
    r2.w = (r0.x < 0) ? 1 : 0;
    r0 = r2.wwww * DebugColor;
    r1 = DebugColor;
    out.COLOR0 = r0 * -0.8 + r1;
    r1.x = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x]);
    r1.y = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 1]);
    r1.z = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 2]);
    r0.xyz = r2.xyz * m_extrusion.xxx;
    r0.xyz = r2.www * -r0.xyz + r1.xyz;
    r0.w = 1;
    out.POSITION.x = dot(r0, m_viewProj[0]);
    out.POSITION.y = dot(r0, m_viewProj[1]);
    out.POSITION.z = dot(r0, m_viewProj[2]);
    out.POSITION.w = dot(r0, m_viewProj[3]);
}
