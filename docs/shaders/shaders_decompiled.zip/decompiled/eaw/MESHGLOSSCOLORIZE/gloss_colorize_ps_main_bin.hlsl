// ps_1_1 MESHGLOSSCOLORIZE::gloss_colorize_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 Colorization : register(c0);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d GlossSampler : register(s1);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(GlossSampler, in.TEXCOORD1);
    r0.xyz = t0.xyz * Colorization.xyz;
    r0.xyz = lerp(t0.xyz, r0.xyz, t0.www);
    r0.xyz = 2 * (r0.xyz * in.COLOR0.xyz);
    r1.xyz = dot(float3(1, 0, 0), t1.xyz);
    r0.xyz = r1.xyz * in.COLOR1.xyz + r0.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
