// vs_1_1 RSKINBUMPREFLECTCOLORIZE::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphFill[3] : register(c72);   // 12 regs
uniform float4x4 m_viewProj : register(c84);   // 4 regs
uniform float4x4 m_world : register(c88);   // 3 regs
uniform float4 m_eyePos : register(c91);
uniform float4 m_light0Vector : register(c92);
uniform float4 m_lightScale : register(c93);
uniform float2 m_fogVals : register(c94);
uniform float3 Emissive : register(c95);
uniform float3 Diffuse : register(c96);
uniform float4 UVOffset : register(c97);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=TANGENT0, v4=BINORMAL0
main {
    r2.w = 1;
    r2.x = dot(in.POSITION0, m_world[0]);
    r2.y = dot(in.POSITION0, m_world[1]);
    r2.z = dot(in.POSITION0, m_world[2]);
    r0.x = dot(in.TANGENT0.xyz, m_world[0].xyz);
    r0.y = dot(in.TANGENT0.xyz, m_world[1].xyz);
    r0.z = dot(in.TANGENT0.xyz, m_world[2].xyz);
    out.POSITION.w = dot(r2, m_viewProj[3]);
    r3.x = dot(m_light0Vector.xyz, r0.xyz);
    r1.x = dot(in.BINORMAL0.xyz, m_world[0].xyz);
    r1.y = dot(in.BINORMAL0.xyz, m_world[1].xyz);
    r1.z = dot(in.BINORMAL0.xyz, m_world[2].xyz);
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r3.y = dot(m_light0Vector.xyz, r1.xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r1.xyz = -r2.xyz + m_eyePos.xyz;
    r0.xyz = r0.xyz * r0.www;
    r4.x = dot(r1.xyz, r1.xyz);
    r3.z = dot(m_light0Vector.xyz, r0.xyz);
    r0.w = rsqrt(r4.x);
    r4.x = dot(r3.xyz, r3.xyz);
    r1.xyz = r1.xyz * r0.www;
    r0.w = rsqrt(r4.x);
    r4.x = dot(r1.xyz, r0.xyz);
    r3.xyz = r3.xyz * r0.www;
    r0.w = r4.x + r4.x;
    out.TEXCOORD2.xyz = r3.xyz * 0.5 + 0.5;
    r3.xyz = r0.www * r0.xyz + -r1.xyz;
    r4.x = dot(r3.xyz, r3.xyz);
    r1 = r0.yyyy * m_sphFill[1];
    r0.w = rsqrt(r4.x);
    r1 = m_sphFill[0] * r0.xxxx + r1;
    out.TEXCOORD3.xyz = r3.xyz * r0.www;
    r1 = m_sphFill[2] * r0.zzzz + r1;
    r3 = r1 + m_sphFill[3];
    r1 = r0.yyyy * m_sphFill[5];
    r0.w = 1;
    r1 = m_sphFill[4] * r0.xxxx + r1;
    r4.x = dot(r0, r3);
    r1 = m_sphFill[6] * r0.zzzz + r1;
    r3 = r1 + m_sphFill[7];
    r1 = r0.yyyy * m_sphFill[9];
    r4.y = dot(r0, r3);
    r1 = m_sphFill[8] * r0.xxxx + r1;
    r1 = m_sphFill[10] * r0.zzzz + r1;
    r3.x = dot(r2, m_viewProj[0]);
    r3.y = dot(r2, m_viewProj[1]);
    r3.z = dot(r2, m_viewProj[2]);
    r1 = r1 + m_sphFill[11];
    r2.x = dot(r3.xyz, r3.xyz);
    r4.z = dot(r0, r1);
    r0.w = rsqrt(r2.x);
    r0.xyz = r4.xyz * Diffuse.xyz;
    r0.w = 1 / r0.w;
    r1.xyz = m_lightScale.xyz;
    out.COLOR0.xyz = r0.xyz * r1.xyz + Emissive.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.POSITION.xyz = r3.xyz;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = m_lightScale.w;
    out.COLOR1 = float4(0, 0, 0, 1);
    r0.xy = in.TEXCOORD0.xy + UVOffset.xy;
    out.TEXCOORD0.xy = r0.xy;
    out.TEXCOORD1.xy = r0.xy;
}
