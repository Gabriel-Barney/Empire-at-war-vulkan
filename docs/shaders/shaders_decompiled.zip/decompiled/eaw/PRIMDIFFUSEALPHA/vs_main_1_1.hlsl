// vs_1_1 PRIMDIFFUSEALPHA::vs_main_1_1  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float4 m_light0Specular : register(c21);
uniform float2 m_fogVals : register(c22);
uniform float3 Diffuse : register(c23);
uniform float3 Specular : register(c24);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=COLOR0
main {
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r0.xyz = r0.xyz * r0.www;
    r1 = r0.yyyy * m_sphAll[1];
    r1 = m_sphAll[0] * r0.xxxx + r1;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r1 = m_sphAll[2] * r0.zzzz + r1;
    r1 = r1 + m_sphAll[3];
    r0.w = 1;
    r2.xyz = in.COLOR0.xyz * Diffuse.xyz;
    r3.x = dot(r0, r1);
    r1 = r0.yyyy * m_sphAll[5];
    r4.x = dot(in.POSITION0, m_world[0]);
    r4.y = dot(in.POSITION0, m_world[1]);
    r4.z = dot(in.POSITION0, m_world[2]);
    r1 = m_sphAll[4] * r0.xxxx + r1;
    r4.xyz = -r4.xyz + m_eyePos.xyz;
    r1 = m_sphAll[6] * r0.zzzz + r1;
    r5.x = dot(r4.xyz, r4.xyz);
    r1 = r1 + m_sphAll[7];
    r2.w = rsqrt(r5.x);
    r3.y = dot(r0, r1);
    r4.xyz = r4.xyz * r2.www + m_light0Vector.xyz;
    r1 = r0.yyyy * m_sphAll[9];
    r5.x = dot(r4.xyz, r4.xyz);
    r1 = m_sphAll[8] * r0.xxxx + r1;
    r2.w = rsqrt(r5.x);
    r1 = m_sphAll[10] * r0.zzzz + r1;
    r4.xyz = r4.xyz * r2.www;
    r1 = r1 + m_sphAll[11];
    r4.x = dot(r0.xyz, r4.xyz);
    r3.z = dot(r0, r1);
    r0.w = max(r4.x, 0);
    out.COLOR0.xyz = r2.xyz * r3.xyz;
    r0.w = r0.w * r0.w;
    r0.w = r0.w * r0.w;
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.w = r0.w * r0.w;
    r1.x = dot(r0.xyz, r0.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r1.x);
    r1.xyz = r1.www * m_light0Specular.xyz;
    r0.w = 1 / r0.w;
    out.COLOR1.xyz = r1.xyz * Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.POSITION.xyz = r0.xyz;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = in.COLOR0.w;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
