// vs_1_1 MESHLIGHTVISUALIZE::sph_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r0.xyz = r0.xyz * r0.www;
    out.POSITION.x = dot(in.POSITION0, m_worldViewProj[0]);
    r1 = r0.yyyy * m_sphAll[1];
    out.POSITION.y = dot(in.POSITION0, m_worldViewProj[1]);
    r1 = m_sphAll[0] * r0.xxxx + r1;
    out.POSITION.z = dot(in.POSITION0, m_worldViewProj[2]);
    r1 = m_sphAll[2] * r0.zzzz + r1;
    r1 = r1 + m_sphAll[3];
    r0.w = 1;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    out.COLOR0.x = dot(r0, r1);
    r2 = r0.yyyy * m_sphAll[5];
    r1 = r0.yyyy * m_sphAll[9];
    r2 = m_sphAll[4] * r0.xxxx + r2;
    r1 = m_sphAll[8] * r0.xxxx + r1;
    r2 = m_sphAll[6] * r0.zzzz + r2;
    r1 = m_sphAll[10] * r0.zzzz + r1;
    r2 = r2 + m_sphAll[7];
    r1 = r1 + m_sphAll[11];
    out.COLOR0.y = dot(r0, r2);
    out.COLOR0.z = dot(r0, r1);
    out.COLOR0.w = 1;
    out.TEXCOORD0.xy = 0;
}
