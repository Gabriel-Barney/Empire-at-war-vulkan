// vs_1_1 TERRAINRENDERBAKED::vs_main_nobump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float2 m_fogVals : register(c19);
uniform float4 diffuseTexU : register(c20);
uniform float4 diffuseTexV : register(c21);

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r2.x = dot(r0.xyz, r0.xyz);
    r1 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r0.w = rsqrt(r2.x);
    out.POSITION.w = dot(r1, m_worldViewProj[3]);
    r0.xyz = r0.xyz * r0.www;
    out.TEXCOORD0.x = dot(diffuseTexU, r1);
    r2 = r0.yyyy * m_sphAll[1];
    out.TEXCOORD0.y = dot(diffuseTexV, r1);
    r2 = m_sphAll[0] * r0.xxxx + r2;
    r3 = m_sphAll[2] * r0.zzzz + r2;
    r2 = r0.yyyy * m_sphAll[5];
    r3 = r3 + m_sphAll[3];
    r2 = m_sphAll[4] * r0.xxxx + r2;
    r0.w = 1;
    r2 = m_sphAll[6] * r0.zzzz + r2;
    out.COLOR0.x = dot(r0, r3);
    r2 = r2 + m_sphAll[7];
    out.COLOR0.y = dot(r0, r2);
    r2.x = dot(r1, m_worldViewProj[0]);
    r2.y = dot(r1, m_worldViewProj[1]);
    r2.z = dot(r1, m_worldViewProj[2]);
    r1 = r0.yyyy * m_sphAll[9];
    r3.x = dot(r2.xyz, r2.xyz);
    r1 = m_sphAll[8] * r0.xxxx + r1;
    r2.w = rsqrt(r3.x);
    r1 = m_sphAll[10] * r0.zzzz + r1;
    r2.w = 1 / r2.w;
    r1 = r1 + m_sphAll[11];
    r2.w = m_fogVals.x * r2.w + m_fogVals.y;
    out.COLOR0.z = dot(r0, r1);
    r0.w = max(r2.w, 0);
    out.POSITION.xyz = r2.xyz;
    out.FOG = min(r0.wwww, 1);
    out.TEXCOORD1.xy = 0;
    out.COLOR0.w = 1;
}
