// ps_1_1 TERRAINRENDERBAKED::ps_main_nobump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d TextureSampler : register(s0);

main {
    t0 = tex2D(TextureSampler, in.TEXCOORD0);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r0.w = 1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
