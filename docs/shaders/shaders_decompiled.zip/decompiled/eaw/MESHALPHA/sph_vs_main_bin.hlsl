// vs_1_1 MESHALPHA::sph_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float4 m_light0Specular : register(c21);
uniform float4 m_lightScale : register(c22);
uniform float2 m_fogVals : register(c23);
uniform float3 Emissive : register(c24);
uniform float4 Diffuse : register(c25);
uniform float3 Specular : register(c26);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r1.x = dot(r0.xyz, r0.xyz);
    r0.w = rsqrt(r1.x);
    r1.xyz = r0.xyz * r0.www;
    r0 = r1.yyyy * m_sphAll[1];
    r0 = m_sphAll[0] * r1.xxxx + r0;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0 = m_sphAll[2] * r1.zzzz + r0;
    r2 = r0 + m_sphAll[3];
    r0 = r1.yyyy * m_sphAll[5];
    r1.w = 1;
    r0 = m_sphAll[4] * r1.xxxx + r0;
    r3.x = dot(r1, r2);
    r0 = m_sphAll[6] * r1.zzzz + r0;
    r0 = r0 + m_sphAll[7];
    r2.x = dot(in.POSITION0, m_world[0]);
    r2.y = dot(in.POSITION0, m_world[1]);
    r2.z = dot(in.POSITION0, m_world[2]);
    r3.y = dot(r1, r0);
    r2.xyz = -r2.xyz + m_eyePos.xyz;
    r0 = r1.yyyy * m_sphAll[9];
    r4.x = dot(r2.xyz, r2.xyz);
    r0 = m_sphAll[8] * r1.xxxx + r0;
    r2.w = rsqrt(r4.x);
    r0 = m_sphAll[10] * r1.zzzz + r0;
    r2.xyz = r2.xyz * r2.www + m_light0Vector.xyz;
    r0 = r0 + m_sphAll[11];
    r4.x = dot(r2.xyz, r2.xyz);
    r3.z = dot(r1, r0);
    r0.w = rsqrt(r4.x);
    r3.xyz = r3.xyz * Diffuse.xyz;
    r2.xyz = r2.xyz * r0.www;
    r0 = m_lightScale;
    out.COLOR0.xyz = r3.xyz * r0.xyz + Emissive.xyz;
    r0.x = dot(r1.xyz, r2.xyz);
    out.COLOR0.w = r0.w * Diffuse.w;
    r0.w = max(r0.x, 0);
    r0.w = r0.w * r0.w;
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.w = r0.w * r0.w;
    r1.x = dot(r0.xyz, r0.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r1.x);
    r1.w = r1.w * r1.w;
    r0.w = 1 / r0.w;
    r1.xyz = r1.www * m_light0Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.COLOR1.xyz = r1.xyz * Specular.xyz;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r0.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
