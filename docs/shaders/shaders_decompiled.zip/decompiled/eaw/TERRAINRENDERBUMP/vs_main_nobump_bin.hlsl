// vs_1_1 TERRAINRENDERBUMP::vs_main_nobump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_worldViewProj : register(c12);   // 4 regs
uniform float4x4 m_world : register(c16);   // 3 regs
uniform float4 m_eyePos : register(c19);
uniform float4 m_light0Vector : register(c20);
uniform float4 m_light0Specular : register(c21);
uniform float2 m_fogVals : register(c22);
uniform float4 m_cloudTexU : register(c23);
uniform float4 m_cloudTexV : register(c24);
uniform float4 diffuseTexU : register(c25);
uniform float4 diffuseTexV : register(c26);
uniform float2 blendTexScale : register(c27);
uniform float2 blendTexOffset : register(c28);
uniform float4 materialDiffuse : register(c29);
uniform float4 materialSpecular : register(c30);

// inputs: v0=POSITION0, v1=NORMAL0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r1.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r1.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r1.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r2.x = dot(r1.xyz, r1.xyz);
    out.TEXCOORD1.x = dot(diffuseTexU, r0);
    r1.w = rsqrt(r2.x);
    out.TEXCOORD1.y = dot(diffuseTexV, r0);
    r1.xyz = r1.xyz * r1.www;
    r2.xy = blendTexScale.xy;
    out.TEXCOORD0.xy = r2.xy * in.POSITION0.xy + blendTexOffset.xy;
    r2 = r1.yyyy * m_sphAll[1];
    out.TEXCOORD2.x = dot(m_cloudTexU, r0);
    r2 = m_sphAll[0] * r1.xxxx + r2;
    out.TEXCOORD2.y = dot(m_cloudTexV, r0);
    r2 = m_sphAll[2] * r1.zzzz + r2;
    r2 = r2 + m_sphAll[3];
    r1.w = 1;
    r3.x = dot(r1, r2);
    r2 = r1.yyyy * m_sphAll[5];
    r2 = m_sphAll[4] * r1.xxxx + r2;
    r4.x = dot(in.POSITION0.xyz, m_world[0].xyz);
    r4.y = dot(in.POSITION0.xyz, m_world[1].xyz);
    r4.z = dot(in.POSITION0.xyz, m_world[2].xyz);
    r2 = m_sphAll[6] * r1.zzzz + r2;
    r4.xyz = -r4.xyz + m_eyePos.xyz;
    r2 = r2 + m_sphAll[7];
    r5.x = dot(r4.xyz, r4.xyz);
    r3.y = dot(r1, r2);
    r3.w = rsqrt(r5.x);
    r2 = r1.yyyy * m_sphAll[9];
    r4.xyz = r4.xyz * r3.www + m_light0Vector.xyz;
    r2 = m_sphAll[8] * r1.xxxx + r2;
    r5.x = dot(r4.xyz, r4.xyz);
    r2 = m_sphAll[10] * r1.zzzz + r2;
    r3.w = rsqrt(r5.x);
    r2 = r2 + m_sphAll[11];
    r4.xyz = r4.xyz * r3.www;
    r3.z = dot(r1, r2);
    r1.x = dot(r1.xyz, r4.xyz);
    out.COLOR0.xyz = r3.xyz * materialDiffuse.xyz;
    r1.w = max(r1.x, 0);
    r1.w = r1.w * r1.w;
    r1.x = dot(r0, m_worldViewProj[0]);
    r1.y = dot(r0, m_worldViewProj[1]);
    r1.z = dot(r0, m_worldViewProj[2]);
    r0.w = r1.w * r1.w;
    r0.x = dot(r1.xyz, r1.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r0.x);
    r1.w = r1.w * r1.w;
    r0.w = 1 / r0.w;
    r0.xyz = r1.www * m_light0Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.COLOR1.xyz = r0.xyz * materialSpecular.xyz;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = 1;
    out.COLOR1.w = 1;
}
