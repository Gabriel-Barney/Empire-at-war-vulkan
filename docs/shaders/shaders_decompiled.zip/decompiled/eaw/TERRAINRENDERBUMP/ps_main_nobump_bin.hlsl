// ps_1_1 TERRAINRENDERBUMP::ps_main_nobump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BlendSampler : register(s0);
uniform sampler2d TextureSampler : register(s1);
uniform sampler2d CloudSampler : register(s2);

main {
    t0 = tex2D(BlendSampler, in.TEXCOORD0);
    t1 = tex2D(TextureSampler, in.TEXCOORD1);
    t2 = tex2D(CloudSampler, in.TEXCOORD2);
    r0.xyz = 2 * (t1.xyz * in.COLOR0.xyz);
    r0.xyz = t1.www * in.COLOR1.xyz + r0.xyz;
    r0.xyz = t2.xyz * r0.xyz;
    r0.w = t0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
