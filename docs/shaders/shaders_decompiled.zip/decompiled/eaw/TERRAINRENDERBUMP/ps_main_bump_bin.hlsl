// ps_1_4 TERRAINRENDERBUMP::ps_main_bump_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float4 materialDiffuse : register(c2);
uniform float4 materialSpecular : register(c3);
uniform sampler2d NormalSampler : register(s0);
uniform sampler2d CloudSampler : register(s1);
uniform sampler2d TextureSampler : register(s2);
uniform sampler2d BlendSampler : register(s3);

main {
    r0 = tex2D(NormalSampler, in.TEXCOORD1.xyz);
    r1 = tex2D(CloudSampler, in.TEXCOORD2.xyz);
    r2.xyz = in.TEXCOORD3.xyz;
    r3.xyz = in.TEXCOORD4.xyz;
    r4.xyz = m_light0Specular.xyz * materialSpecular.xyz;
    r3.w = saturate(dot((2 * r0.xyz - 1), (2 * r3.xyz - 1)));
    r3.w = r3.w * r3.w;
    r3.w = r3.w * r3.w;
    r3.w = r3.w * r3.w;
    r3.w = r3.w * r3.w;
    r4.xyz = r3.www * r4.xyz;
    r5.xyz = r2.xyz;
    // phase (ps_1_4: second texture-addressing phase)
    r2 = tex2D(TextureSampler, in.TEXCOORD1.xyz);
    r3 = tex2D(BlendSampler, in.TEXCOORD0.xyz);
    r0.w = saturate(dot((2 * r0.xyz - 1), (2 * r5.xyz - 1)));
    r0.xyz = r0.www * materialDiffuse.xyz;
    r0.xyz = r0.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r0.xyz = r2.xyz * r0.xyz;
    r0.xyz = r2.www * r4.xyz + (2 * r0.xyz);
    r0.xyz = r1.xyz * r0.xyz;
    r0.w = r3.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
