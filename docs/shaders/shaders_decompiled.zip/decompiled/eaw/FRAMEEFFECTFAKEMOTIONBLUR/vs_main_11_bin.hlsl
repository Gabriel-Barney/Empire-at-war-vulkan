// vs_1_1 FRAMEEFFECTFAKEMOTIONBLUR::vs_main_11_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_resolutionConstants : register(c0);
uniform float RadialBlur : register(c1);

// inputs: v0=POSITION0
main {
    r0 = float4(0.5, -0.5, 0.3, 1);
    r0.xy = in.POSITION0.xy * r0.xy + m_resolutionConstants.zw;
    r0.w = RadialBlur.x * -r0.z + r0.w;
    out.TEXCOORD0.xy = r0.ww * r0.xy + 0.5;
    out.POSITION = in.POSITION0.xyxx * float4(1, 1, 0, 0) + float4(0, 0, 0.5, 1);
    out.FOG = 1;
}
