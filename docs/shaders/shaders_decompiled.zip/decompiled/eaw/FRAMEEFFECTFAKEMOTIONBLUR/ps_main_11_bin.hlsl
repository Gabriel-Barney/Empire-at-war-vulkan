// ps_1_1 FRAMEEFFECTFAKEMOTIONBLUR::ps_main_11_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float BlendFactor : register(c0);
uniform sampler2d PrevFrameSampler : register(s0);

main {
    t0 = tex2D(PrevFrameSampler, in.TEXCOORD0);
    r0.xyz = t0.xyz;
    r1 = dot(float3(1, 0, 0), BlendFactor.xyz);
    r0.w = r1.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
