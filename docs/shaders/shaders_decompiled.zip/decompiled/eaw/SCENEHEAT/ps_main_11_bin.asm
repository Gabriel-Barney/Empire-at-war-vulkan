// SCENEHEAT :: ps_main_11_bin  (sha1 669f3ae93db7)
ps_1_1
    tex t0
    texbem t1, t0
    mov r0, t1
// 3 instruction slots used
