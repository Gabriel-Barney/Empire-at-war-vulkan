// vs_1_1 SCENEHEAT::vs_main_11_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_resolutionConstants : register(c0);
uniform float DistortionAmount : register(c1);

// inputs: v0=POSITION0
main {
    r0.xyz = float3(0.5, -0.5, 10);
    r2.xy = in.POSITION0.xy * r0.xy + m_resolutionConstants.zw;
    r1.xy = r2.xy + 0.5;
    r1.xy = m_resolutionConstants.zw * r0.zz + r1.xy;
    out.TEXCOORD0.xy = r2.xy + 0.5;
    out.TEXCOORD1.xy = DistortionAmount.xx * -r0.xx + r1.xy;
    out.POSITION = in.POSITION0.xyxx * float4(1, 1, 0, 0) + float4(0, 0, 0.5, 1);
    out.FOG = 1;
}
