// ps_1_1 SCENEHEAT::ps_main_11_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)

main {
    t0 = tex2D(sampler0, in.TEXCOORD0);
    t1 = tex2D(sampler1, in.TEXCOORD1.xy + bumpEnvMat1 * t0.xy);
    r0 = t1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
