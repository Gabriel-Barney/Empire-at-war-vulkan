// ps_2_0 SCENEHEAT::ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float DistortionAmount : register(c0);
uniform sampler2d DistortionSampler : register(s0);
uniform sampler2d SceneSampler : register(s1);

main {
    r0 = tex2D(DistortionSampler, in.TEXCOORD0);
    r0.xy = r0.xy + -0.5;
    r0.w = DistortionAmount.x + DistortionAmount.x;
    r0.xy = r0.ww * r0.xy + in.TEXCOORD0.xy;
    r0 = tex2D(SceneSampler, r0);
    out.COLOR0 = r0;
}
