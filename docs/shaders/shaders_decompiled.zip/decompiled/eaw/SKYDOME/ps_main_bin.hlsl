// ps_1_1 SKYDOME::ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d CloudSampler : register(s1);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(CloudSampler, in.TEXCOORD1);
    r0.w = t1.w * in.COLOR0.w;
    r1.w = -r0.w + 1;
    r1.xyz = t0.xyz * r1.www;
    r0.xyz = t1.xyz * r0.www + r1.xyz;
    r0.xyz = 2 * (r0.xyz * in.COLOR0.xyz);
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
