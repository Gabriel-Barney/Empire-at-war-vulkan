// vs_1_1 MESHHEAT::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float m_time : register(c4);
uniform float2 UVScrollRate : register(c5);

// inputs: v0=POSITION0, v1=TEXCOORD0, v2=COLOR0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    out.POSITION.z = dot(r0, m_worldViewProj[2]);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r0.w = m_time.x;
    out.TEXCOORD0.xy = r0.ww * UVScrollRate.xy + in.TEXCOORD0.xy;
    out.COLOR0 = in.COLOR0;
    out.FOG = 1;
}
