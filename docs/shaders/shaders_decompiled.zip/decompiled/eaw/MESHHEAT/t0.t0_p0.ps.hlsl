// ps_1_1 MESHHEAT::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d DistortionSampler : register(s0);

main {
    t0 = tex2D(DistortionSampler, in.TEXCOORD0);
    r0.xyz = t0.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
