// vs_1_1 TERRAINLAVA::t1.t1_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_world : register(c12);   // 4 regs
uniform float4x4 m_worldViewProj : register(c16);   // 4 regs
uniform float4 m_eyePos : register(c20);
uniform float4 m_light0Vector : register(c21);
uniform float4 m_light0Specular : register(c22);
uniform float2 m_fogVals : register(c23);
uniform float4 m_FOWTexU : register(c24);
uniform float4 m_FOWTexV : register(c25);
uniform float4 BaseTexU : register(c26);
uniform float4 BaseTexV : register(c27);
uniform float4 CrustTexU : register(c28);
uniform float4 CrustTexV : register(c29);
uniform float4 CrustSpecular : register(c30);

// inputs: v0=POSITION0
main {
    r1 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.w = dot(r1, m_worldViewProj[3]);
    r0.w = dot(r1, m_world[3]);
    r0.x = dot(r1, m_world[0]);
    r0.y = dot(r1, m_world[1]);
    r0.z = dot(r1, m_world[2]);
    out.TEXCOORD0.x = dot(BaseTexU, r0);
    out.TEXCOORD0.y = dot(BaseTexV, r0);
    out.TEXCOORD3.x = dot(m_FOWTexU, r0);
    r3.xyz = -r0.xyz + m_eyePos.xyz;
    out.TEXCOORD3.y = dot(m_FOWTexV, r0);
    r4.x = dot(r3.xyz, r3.xyz);
    r2 = m_sphAll[2];
    r2 = r2 + m_sphAll[3];
    r3.w = rsqrt(r4.x);
    out.COLOR0.x = dot(float4(0, 0, 1, 1), r2);
    r3.xyz = r3.xyz * r3.www + m_light0Vector.xyz;
    r2 = m_sphAll[6];
    r2 = r2 + m_sphAll[7];
    r3.x = dot(r3.xyz, r3.xyz);
    out.COLOR0.y = dot(float4(0, 0, 1, 1), r2);
    r3.w = rsqrt(r3.x);
    r2 = m_sphAll[10];
    r2 = r2 + m_sphAll[11];
    r3.w = r3.z * r3.w;
    out.COLOR0.z = dot(float4(0, 0, 1, 1), r2);
    r2.w = max(r3.w, 0);
    r2.w = r2.w * r2.w;
    r2.x = dot(r1, m_worldViewProj[0]);
    r2.y = dot(r1, m_worldViewProj[1]);
    r2.z = dot(r1, m_worldViewProj[2]);
    r1.w = r2.w * r2.w;
    r1.x = dot(r2.xyz, r2.xyz);
    r2.w = r1.w * r1.w;
    r1.w = rsqrt(r1.x);
    r2.w = r2.w * r2.w;
    r1.w = 1 / r1.w;
    r1.xyz = r2.www * m_light0Specular.xyz;
    r1.w = m_fogVals.x * r1.w + m_fogVals.y;
    out.COLOR1.xyz = r1.xyz * CrustSpecular.xyz;
    r1.w = max(r1.w, 0);
    out.POSITION.xyz = r2.xyz;
    out.FOG = min(r1.wwww, 1);
    r1.x = dot(CrustTexU, r0);
    r1.y = dot(CrustTexV, r0);
    out.TEXCOORD1.xy = r1.xy;
    out.TEXCOORD2.xy = r1.xy;
    out.COLOR0.w = 1;
    out.COLOR1.w = 1;
}
