// ps_1_1 TERRAINLAVA::t1.t1_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d CrustSampler : register(s1);
uniform sampler2d CrustBumpSampler : register(s2);
uniform sampler2d FOWSampler : register(s3);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(CrustSampler, in.TEXCOORD1);
    t2 = tex2D(CrustBumpSampler, in.TEXCOORD2);
    t3 = tex2D(FOWSampler, in.TEXCOORD3);
    r0.xyz = 2 * (t1.xyz * in.COLOR0.xyz);
    r1.xyz = dot(float3(0, 0, 1), t2.xyz);
    r0.xyz = r1.xyz * in.COLOR1.xyz + r0.xyz;
    r0.xyz = lerp(t0.xyz, r0.xyz, t1.www);
    r0.xyz = t3.xyz * r0.xyz;
    r0.w = 1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
