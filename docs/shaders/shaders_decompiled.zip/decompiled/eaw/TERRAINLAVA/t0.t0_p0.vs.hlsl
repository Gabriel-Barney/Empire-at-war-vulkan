// vs_1_1 TERRAINLAVA::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphFill[3] : register(c0);   // 12 regs
uniform float4x4 m_world : register(c12);   // 4 regs
uniform float4x4 m_worldViewProj : register(c16);   // 4 regs
uniform float4 m_eyePos : register(c20);
uniform float4 m_light0Vector : register(c21);
uniform float2 m_fogVals : register(c22);
uniform float4 m_FOWTexU : register(c23);
uniform float4 m_FOWTexV : register(c24);
uniform float4 BaseTexU : register(c25);
uniform float4 BaseTexV : register(c26);
uniform float4 CrustTexU : register(c27);
uniform float4 CrustTexV : register(c28);

// inputs: v0=POSITION0
main {
    r2 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r0.w = dot(r2, m_world[3]);
    r0.x = dot(r2, m_world[0]);
    r0.y = dot(r2, m_world[1]);
    r0.z = dot(r2, m_world[2]);
    out.POSITION.w = dot(r2, m_worldViewProj[3]);
    out.TEXCOORD0.x = dot(BaseTexU, r0);
    out.TEXCOORD0.y = dot(BaseTexV, r0);
    r4.xy = float2(1, 0);
    r1.xyz = r4.xxy * CrustTexU.xyx;
    out.TEXCOORD3.x = dot(m_FOWTexU, r0);
    r1.x = dot(r1.xyz, r1.xyz);
    out.TEXCOORD3.y = dot(m_FOWTexV, r0);
    r1.w = rsqrt(r1.x);
    r5.xy = r1.ww * CrustTexU.xy;
    r5.z = 0;
    r3.x = dot(m_light0Vector.xyz, r5.xyz);
    r1.xyz = -r0.xyz + m_eyePos.xyz;
    r4.xyz = r4.xxy * CrustTexV.xyx;
    r6.x = dot(r1.xyz, r1.xyz);
    r4.x = dot(r4.xyz, r4.xyz);
    r3.w = rsqrt(r6.x);
    r1.w = rsqrt(r4.x);
    r1.xyz = r1.xyz * r3.www + m_light0Vector.xyz;
    r4.xy = r1.ww * CrustTexV.xy;
    r6.x = dot(r1.xyz, r1.xyz);
    r4.z = 0;
    r1.w = rsqrt(r6.x);
    r3.y = dot(m_light0Vector.xyz, r4.xyz);
    r1.yzw = r1.xzy * r1.www;
    r3.z = m_light0Vector.z;
    r1.x = dot(r1.ywz, r5.xyz);
    r1.y = dot(r1.ywz, r4.xyz);
    r5.x = dot(r3.xyz, r3.xyz);
    r4.x = dot(r1.xyz, r1.xyz);
    r3.w = rsqrt(r5.x);
    r1.w = rsqrt(r4.x);
    r3.xyz = r3.xyz * r3.www;
    r1.xyz = r1.xyz * r1.www;
    out.TEXCOORD4.xyz = r3.xyz * 0.5 + 0.5;
    out.TEXCOORD5.xyz = r1.xyz * 0.5 + 0.5;
    r1 = m_sphFill[2];
    r1 = r1 + m_sphFill[3];
    r3.x = dot(r2, m_worldViewProj[0]);
    r3.y = dot(r2, m_worldViewProj[1]);
    r3.z = dot(r2, m_worldViewProj[2]);
    out.COLOR0.x = dot(float4(0, 0, 1, 1), r1);
    r2.x = dot(r3.xyz, r3.xyz);
    r1 = m_sphFill[6];
    r1 = r1 + m_sphFill[7];
    r2.w = rsqrt(r2.x);
    out.COLOR0.y = dot(float4(0, 0, 1, 1), r1);
    r2.w = 1 / r2.w;
    r1 = m_sphFill[10];
    r1 = r1 + m_sphFill[11];
    r2.w = m_fogVals.x * r2.w + m_fogVals.y;
    out.COLOR0.z = dot(float4(0, 0, 1, 1), r1);
    r1.w = max(r2.w, 0);
    out.POSITION.xyz = r3.xyz;
    out.FOG = min(r1.wwww, 1);
    r1.x = dot(CrustTexU, r0);
    r1.y = dot(CrustTexV, r0);
    out.TEXCOORD1.xy = r1.xy;
    out.TEXCOORD2.xy = r1.xy;
    out.COLOR0.w = 1;
    out.COLOR1 = 0;
}
