// ps_2_0 TERRAINLAVA::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float4 CrustSpecular : register(c2);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d CrustSampler : register(s1);
uniform sampler2d CrustBumpSampler : register(s2);
uniform sampler2d FOWSampler : register(s3);

// inputs: v0=COLOR0
main {
    r3 = tex2D(CrustBumpSampler, in.TEXCOORD2);
    r1 = tex2D(CrustSampler, in.TEXCOORD1);
    r2 = tex2D(BaseSampler, in.TEXCOORD0);
    r0 = tex2D(FOWSampler, in.TEXCOORD3);
    r4.xyz = in.TEXCOORD4.xyz + -0.5;
    r5.xyz = r4.xyz + r4.xyz;
    r3.xyz = r3.xyz + -0.5;
    r4.xyz = r3.xyz + r3.xyz;
    r3.x = saturate(dot(r4.xyz, r5.xyz));
    r3.xyz = r3.xxx * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r1.xyz = r1.xyz * r3.xyz;
    r3.xyz = r1.xyz + r1.xyz;
    r1.xyz = in.TEXCOORD5.xyz + -0.5;
    r1.xyz = r1.xyz + r1.xyz;
    r4.x = saturate(dot(r4.xyz, r1.xyz));
    r1.xyz = CrustSpecular.xyz;
    r1.xyz = r1.xyz * m_light0Specular.xyz;
    r0.w = r4.x * r4.x;
    r1.xyz = r4.xxx * r1.xyz;
    r0.w = r0.w * r0.w;
    r1.xyz = r1.xyz * r0.www + r3.xyz;
    r3.xyz = lerp(r2.xyz, r1.xyz, r1.www);
    r0.xyz = r0.xyz * r3.xyz;
    r0.w = 1;
    out.COLOR0 = r0;
}
