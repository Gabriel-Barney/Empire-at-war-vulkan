// vs_1_1 RSKINHEAT::vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x3 m_skinMatrixArray[24] : register(c0);   // 72 regs
uniform float4x4 m_viewProj : register(c72);   // 4 regs

// CPU preshader: computes shader constants c# from effect parameters
cpu: c76.xy = m_time.x * UVScrollRate.xy;

// inputs: v0=POSITION0, v1=NORMAL0, v2=COLOR0, v3=TEXCOORD0
main {
    r0.w = (in.NORMAL0.w < -in.NORMAL0.w) ? 1 : 0;
    r3.y = frac(in.NORMAL0.w);
    r1.w = r3.y;
    r2.w = -r1.w + in.NORMAL0.w;
    r1.w = (-r1.w < r1.w) ? 1 : 0;
    r0.w = r0.w * r1.w + r2.w;
    r0.w = r0.w * 3;
    a0.x = (int)r0.w;   // vs_1_1 mov to a0 truncates toward zero
    r0.x = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x]);
    r0.y = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 1]);
    r0.z = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 2]);
    r0.w = 1;
    out.POSITION.x = dot(r0, m_viewProj[0]);
    out.POSITION.y = dot(r0, m_viewProj[1]);
    out.POSITION.z = dot(r0, m_viewProj[2]);
    out.POSITION.w = dot(r0, m_viewProj[3]);
    out.TEXCOORD0.xy = in.TEXCOORD0.xy + c76.xy;
    out.COLOR0 = in.COLOR0;
    out.FOG = 1;
}
