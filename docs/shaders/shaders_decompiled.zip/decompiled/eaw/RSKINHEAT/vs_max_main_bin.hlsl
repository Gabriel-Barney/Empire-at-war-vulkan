// vs_1_1 RSKINHEAT::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_viewProj : register(c72);   // 4 regs
uniform float4x4 m_world : register(c76);   // 3 regs

// CPU preshader: computes shader constants c# from effect parameters
cpu: c79.xy = m_time.x * UVScrollRate.xy;

// inputs: v0=POSITION0, v1=COLOR0, v2=TEXCOORD0
main {
    r0.x = dot(in.POSITION0, m_world[0]);
    r0.y = dot(in.POSITION0, m_world[1]);
    r0.z = dot(in.POSITION0, m_world[2]);
    r0.w = 1;
    out.POSITION.x = dot(r0, m_viewProj[0]);
    out.POSITION.y = dot(r0, m_viewProj[1]);
    out.POSITION.z = dot(r0, m_viewProj[2]);
    out.POSITION.w = dot(r0, m_viewProj[3]);
    out.TEXCOORD0.xy = in.TEXCOORD0.xy + c79.xy;
    out.COLOR0 = in.COLOR0;
    out.FOG = 1;
}
