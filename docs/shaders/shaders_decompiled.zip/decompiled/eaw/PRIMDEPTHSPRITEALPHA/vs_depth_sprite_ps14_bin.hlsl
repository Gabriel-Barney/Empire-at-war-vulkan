// vs_1_1 PRIMDEPTHSPRITEALPHA::vs_depth_sprite_ps14_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4x4 m_projection : register(c4);   // 3 regs
uniform float DepthScale : register(c7);

// inputs: v0=POSITION0, v1=TEXCOORD0, v2=COLOR0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.x = dot(r0, m_worldViewProj[0]);
    out.POSITION.y = dot(r0, m_worldViewProj[1]);
    r2.w = DepthScale.x;
    out.TEXCOORD1.x = -r2.w * m_projection[2].z;
    r1.w = dot(r0, m_worldViewProj[3]);
    r1.z = dot(r0, m_worldViewProj[2]);
    out.TEXCOORD2.x = -r2.w * m_projection[2].w;
    out.POSITION.zw = r1.zw;
    out.TEXCOORD2.yz = r1.zw * float2(0, 1);
    out.TEXCOORD1.yz = r1.zz * float2(0, 1);
    out.COLOR0 = in.COLOR0;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
