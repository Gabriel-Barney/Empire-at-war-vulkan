// PRIMHEAT :: ps_main_11_bin  (sha1 77009447962c)
ps_1_1
    tex t0
    texbem t1, t0
    tex t2
    mov r0, t1
    mov r0.w, t2.w
// 5 instruction slots used
