// vs_1_1 PRIMHEAT::vs_main_ati_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4 m_resolutionConstants : register(c4);

// inputs: v0=POSITION0, v1=COLOR0, v2=TEXCOORD0
main {
    out.POSITION.z = dot(in.POSITION0, m_worldViewProj[2]);
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r1.w = 1 / r0.w;
    r1.x = r0.x * r1.w;
    r1.y = -r0.y * r1.w;
    out.POSITION.xyw = r0.xyw;
    r0.w = 0.5;
    r0.xy = r1.xy * r0.ww + m_resolutionConstants.zw;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
    out.TEXCOORD1.xy = r0.xy + 0.5;
    out.TEXCOORD1.z = in.COLOR0.w;
    out.FOG = 1;
}
