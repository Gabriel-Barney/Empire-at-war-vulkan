// ps_1_4 PRIMHEAT::ps_main_ati_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float DistortionAmount : register(c0);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d SceneSampler : register(s1);

main {
    r0 = tex2D(BaseSampler, in.TEXCOORD0.xyz);
    r1.xyz = in.TEXCOORD1.xyz;
    r2.w = r0.w * r1.z;
    r2.w = r2.w * DistortionAmount.x;
    r0.xy = (2 * r0.xy - 1) * r2.ww + r1.xy;
    // phase (ps_1_4: second texture-addressing phase)
    r1 = tex2D(SceneSampler, r0.xyz);
    r0 = r1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
