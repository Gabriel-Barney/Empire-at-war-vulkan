// vs_1_1 RSKINBUMPCOLORIZE::sph_bump_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x3 m_skinMatrixArray[24] : register(c0);   // 72 regs
uniform float4x4 m_sphFill[3] : register(c72);   // 12 regs
uniform float4x4 m_viewProj : register(c84);   // 4 regs
uniform float4 m_eyePos : register(c88);
uniform float4 m_light0Vector : register(c89);
uniform float4 m_light0Specular : register(c90);
uniform float4 m_lightScale : register(c91);
uniform float2 m_fogVals : register(c92);
uniform float3 Emissive : register(c93);
uniform float3 Diffuse : register(c94);
uniform float3 Specular : register(c95);
uniform float4 UVOffset : register(c96);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=TANGENT0, v4=BINORMAL0
main {
    r0.w = (in.NORMAL0.w < -in.NORMAL0.w) ? 1 : 0;
    r6.y = frac(in.NORMAL0.w);
    r1.w = r6.y;
    r2.w = -r1.w + in.NORMAL0.w;
    r1.w = (-r1.w < r1.w) ? 1 : 0;
    r0.w = r0.w * r1.w + r2.w;
    r2.w = r0.w * 3;
    a0.x = (int)r2.w;   // vs_1_1 mov to a0 truncates toward zero
    r0.x = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x]);
    r0.y = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 1]);
    r0.z = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 2]);
    r0.w = 1;
    r1.x = dot(in.TANGENT0.xyz, m_skinMatrixArray.reg[a0.x].xyz);
    r1.y = dot(in.TANGENT0.xyz, m_skinMatrixArray.reg[a0.x + 1].xyz);
    r1.z = dot(in.TANGENT0.xyz, m_skinMatrixArray.reg[a0.x + 2].xyz);
    r3.x = dot(m_light0Vector.xyz, r1.xyz);
    r1.x = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x].xyz);
    r1.y = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 1].xyz);
    r1.z = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 2].xyz);
    r2.x = dot(in.BINORMAL0.xyz, m_skinMatrixArray.reg[a0.x].xyz);
    r4.x = dot(r1.xyz, r1.xyz);
    r2.y = dot(in.BINORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 1].xyz);
    r1.w = rsqrt(r4.x);
    r2.z = dot(in.BINORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 2].xyz);
    r1.xyz = r1.xyz * r1.www;
    r3.y = dot(m_light0Vector.xyz, r2.xyz);
    r3.z = dot(m_light0Vector.xyz, r1.xyz);
    out.POSITION.w = dot(r0, m_viewProj[3]);
    r2.x = dot(r3.xyz, r3.xyz);
    r1.w = rsqrt(r2.x);
    r2 = r1.yyyy * m_sphFill[1];
    r3.xyz = r3.xyz * r1.www;
    r2 = m_sphFill[0] * r1.xxxx + r2;
    out.TEXCOORD2.xyz = r3.xyz * 0.5 + 0.5;
    r2 = m_sphFill[2] * r1.zzzz + r2;
    r3 = r2 + m_sphFill[3];
    r2 = r1.yyyy * m_sphFill[5];
    r1.w = 1;
    r2 = m_sphFill[4] * r1.xxxx + r2;
    r4.x = dot(r1, r3);
    r2 = m_sphFill[6] * r1.zzzz + r2;
    r2 = r2 + m_sphFill[7];
    r3.xyz = -r0.xyz + m_eyePos.xyz;
    r4.y = dot(r1, r2);
    r5.x = dot(r3.xyz, r3.xyz);
    r2 = r1.yyyy * m_sphFill[9];
    r3.w = rsqrt(r5.x);
    r2 = m_sphFill[8] * r1.xxxx + r2;
    r3.xyz = r3.xyz * r3.www + m_light0Vector.xyz;
    r2 = m_sphFill[10] * r1.zzzz + r2;
    r5.x = dot(r3.xyz, r3.xyz);
    r2 = r2 + m_sphFill[11];
    r3.w = rsqrt(r5.x);
    r4.z = dot(r1, r2);
    r3.xyz = r3.xyz * r3.www;
    r2.xyz = r4.xyz * Diffuse.xyz;
    r3.x = dot(r1.xyz, r3.xyz);
    r1.xyz = m_lightScale.xyz;
    out.COLOR0.xyz = r2.xyz * r1.xyz + Emissive.xyz;
    r1.w = max(r3.x, 0);
    r1.w = r1.w * r1.w;
    r1.x = dot(r0, m_viewProj[0]);
    r1.y = dot(r0, m_viewProj[1]);
    r1.z = dot(r0, m_viewProj[2]);
    r0.w = r1.w * r1.w;
    r0.x = dot(r1.xyz, r1.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r0.x);
    r1.w = r1.w * r1.w;
    r0.w = 1 / r0.w;
    r0.xyz = r1.www * m_light0Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.COLOR1.xyz = r0.xyz * Specular.xyz;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.w = m_lightScale.w;
    r0.xy = in.TEXCOORD0.xy + UVOffset.xy;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = r0.xy;
    out.TEXCOORD1.xy = r0.xy;
    out.TEXCOORD3.xyz = 0;
}
