// ps_1_1 MESHALPHASCROLL::alpha_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d BaseSampler : register(s0);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r0.w = t0.w * in.COLOR0.w;
    r0.xyz = r0.xyz + in.COLOR1.xyz;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
