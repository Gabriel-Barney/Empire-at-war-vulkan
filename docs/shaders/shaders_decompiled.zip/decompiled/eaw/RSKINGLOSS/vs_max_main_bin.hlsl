// vs_1_1 RSKINGLOSS::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c72);   // 12 regs
uniform float4x4 m_viewProj : register(c84);   // 4 regs
uniform float4x4 m_world : register(c88);   // 3 regs
uniform float4 m_eyePos : register(c91);
uniform float4 m_light0Vector : register(c92);
uniform float4 m_light0Specular : register(c93);
uniform float4 m_lightScale : register(c94);
uniform float3 Emissive : register(c95);
uniform float3 Diffuse : register(c96);
uniform float3 Specular : register(c97);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r2.w = 1;
    r2.x = dot(in.POSITION0, m_world[0]);
    r0.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r0.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r0.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r2.y = dot(in.POSITION0, m_world[1]);
    r1.x = dot(r0.xyz, r0.xyz);
    r2.z = dot(in.POSITION0, m_world[2]);
    r0.w = rsqrt(r1.x);
    out.POSITION.x = dot(r2, m_viewProj[0]);
    r0.xyz = r0.xyz * r0.www;
    out.POSITION.y = dot(r2, m_viewProj[1]);
    r1 = r0.yyyy * m_sphAll[1];
    out.POSITION.z = dot(r2, m_viewProj[2]);
    r1 = m_sphAll[0] * r0.xxxx + r1;
    out.POSITION.w = dot(r2, m_viewProj[3]);
    r1 = m_sphAll[2] * r0.zzzz + r1;
    r3.xyz = -r2.xyz + m_eyePos.xyz;
    r1 = r1 + m_sphAll[3];
    r0.w = 1;
    r4.x = dot(r3.xyz, r3.xyz);
    r2.x = dot(r0, r1);
    r2.w = rsqrt(r4.x);
    r1 = r0.yyyy * m_sphAll[5];
    r3.xyz = r3.xyz * r2.www + m_light0Vector.xyz;
    r1 = m_sphAll[4] * r0.xxxx + r1;
    r4.x = dot(r3.xyz, r3.xyz);
    r1 = m_sphAll[6] * r0.zzzz + r1;
    r2.w = rsqrt(r4.x);
    r1 = r1 + m_sphAll[7];
    r3.xyz = r3.xyz * r2.www;
    r2.y = dot(r0, r1);
    r3.x = dot(r0.xyz, r3.xyz);
    r1 = r0.yyyy * m_sphAll[9];
    r2.w = max(r3.x, 0);
    r1 = m_sphAll[8] * r0.xxxx + r1;
    r2.w = r2.w * r2.w;
    r1 = m_sphAll[10] * r0.zzzz + r1;
    r2.w = r2.w * r2.w;
    r1 = r1 + m_sphAll[11];
    r2.w = r2.w * r2.w;
    r2.z = dot(r0, r1);
    r0.w = r2.w * r2.w;
    r1.xyz = r2.xyz * Diffuse.xyz;
    r0.xyz = r0.www * m_light0Specular.xyz;
    r2.xyz = m_lightScale.xyz;
    out.COLOR0.xyz = r1.xyz * r2.xyz + Emissive.xyz;
    out.COLOR1.xyz = r0.xyz * Specular.xyz;
    out.COLOR0.w = m_lightScale.w;
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
    out.FOG = 0;
}
