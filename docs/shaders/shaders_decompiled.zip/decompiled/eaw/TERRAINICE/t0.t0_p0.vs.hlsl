// vs_1_1 TERRAINICE::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_world : register(c0);   // 4 regs
uniform float4x4 m_worldViewProj : register(c4);   // 4 regs
uniform float4 m_light0Vector : register(c8);
uniform float2 m_fogVals : register(c9);
uniform float4 m_FOWTexU : register(c10);
uniform float4 m_FOWTexV : register(c11);
uniform float4 BaseTexU : register(c12);
uniform float4 BaseTexV : register(c13);
uniform float4 BumpTexU : register(c14);
uniform float4 BumpTexV : register(c15);

// inputs: v0=POSITION0
main {
    r2 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r1.x = dot(r2, m_world[0]);
    r1.y = dot(r2, m_world[1]);
    r1.z = dot(r2, m_world[2]);
    r1.w = dot(r2, m_world[3]);
    out.TEXCOORD0.x = dot(BaseTexU, r1);
    out.TEXCOORD0.y = dot(BaseTexV, r1);
    out.TEXCOORD3.x = dot(BumpTexU, r1);
    r0.w = dot(r2, m_worldViewProj[3]);
    out.TEXCOORD3.y = dot(BumpTexV, r1);
    r3.w = 1 / r0.w;
    r0.x = dot(r2, m_worldViewProj[0]);
    r0.y = dot(r2, m_worldViewProj[1]);
    r0.z = dot(r2, m_worldViewProj[2]);
    r2.xy = r0.xy * r3.ww + 1;
    out.TEXCOORD1.x = r2.x * 0.5;
    out.TEXCOORD1.y = r2.y * -0.5 + 1;
    out.TEXCOORD2.x = dot(m_FOWTexU, r1);
    r3.xy = float2(1, 0);
    r2.xyz = r3.xxy * BaseTexU.xyx;
    out.TEXCOORD2.y = dot(m_FOWTexV, r1);
    r1.x = dot(r2.xyz, r2.xyz);
    r1.w = rsqrt(r1.x);
    r2.xyz = r3.xxy * BaseTexV.xyx;
    r1.xy = r1.ww * BaseTexU.xy;
    r2.x = dot(r2.xyz, r2.xyz);
    r1.z = 0;
    r1.w = rsqrt(r2.x);
    r2.xy = r1.ww * BaseTexV.xy;
    r2.z = 0;
    r1.x = dot(m_light0Vector.xyz, r1.xyz);
    r1.y = dot(m_light0Vector.xyz, r2.xyz);
    r1.z = m_light0Vector.z;
    r3.x = dot(r0.xyz, r0.xyz);
    r2.x = dot(r1.xyz, r1.xyz);
    r1.w = rsqrt(r3.x);
    r2.w = rsqrt(r2.x);
    r1.w = 1 / r1.w;
    r1.xyz = r1.xyz * r2.www;
    r1.w = m_fogVals.x * r1.w + m_fogVals.y;
    out.TEXCOORD4.xyz = r1.xyz * 0.5 + 0.5;
    r1.w = max(r1.w, 0);
    out.POSITION = r0;
    out.FOG = min(r1.wwww, 1);
    out.COLOR0 = 0;
    out.COLOR1 = 0;
}
