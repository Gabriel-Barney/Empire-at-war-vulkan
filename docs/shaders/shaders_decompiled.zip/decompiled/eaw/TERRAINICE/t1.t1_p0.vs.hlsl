// vs_1_1 TERRAINICE::t1.t1_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c0);   // 12 regs
uniform float4x4 m_world : register(c12);   // 4 regs
uniform float4x4 m_worldViewProj : register(c16);   // 4 regs
uniform float2 m_fogVals : register(c20);
uniform float4 m_FOWTexU : register(c21);
uniform float4 m_FOWTexV : register(c22);
uniform float4 BaseTexU : register(c23);
uniform float4 BaseTexV : register(c24);
uniform float4 IceDiffuse : register(c25);

// inputs: v0=POSITION0
main {
    r1 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    r2.x = dot(r1, m_world[0]);
    r2.y = dot(r1, m_world[1]);
    r2.z = dot(r1, m_world[2]);
    r2.w = dot(r1, m_world[3]);
    out.TEXCOORD0.x = dot(BaseTexU, r2);
    r0.w = dot(r1, m_worldViewProj[3]);
    out.TEXCOORD0.y = dot(BaseTexV, r2);
    r3.w = 1 / r0.w;
    r0.x = dot(r1, m_worldViewProj[0]);
    r0.y = dot(r1, m_worldViewProj[1]);
    r0.z = dot(r1, m_worldViewProj[2]);
    r1.xy = r0.xy * r3.ww + 1;
    out.TEXCOORD1.x = r1.x * 0.5;
    out.TEXCOORD1.y = r1.y * -0.5 + 1;
    out.TEXCOORD2.x = dot(m_FOWTexU, r2);
    r1 = m_sphAll[2];
    r1 = r1 + m_sphAll[3];
    out.TEXCOORD2.y = dot(m_FOWTexV, r2);
    r2.x = dot(float4(0, 0, 1, 1), r1);
    r1 = m_sphAll[6];
    r1 = r1 + m_sphAll[7];
    r3.x = dot(r0.xyz, r0.xyz);
    r2.y = dot(float4(0, 0, 1, 1), r1);
    r2.w = rsqrt(r3.x);
    r1 = m_sphAll[10];
    r1 = r1 + m_sphAll[11];
    r2.w = 1 / r2.w;
    r2.z = dot(float4(0, 0, 1, 1), r1);
    r1.w = m_fogVals.x * r2.w + m_fogVals.y;
    out.COLOR0.xyz = r2.xyz * IceDiffuse.xyz;
    r1.w = max(r1.w, 0);
    out.POSITION = r0;
    out.FOG = min(r1.wwww, 1);
    out.COLOR0.w = 1;
    out.COLOR1 = 0;
}
