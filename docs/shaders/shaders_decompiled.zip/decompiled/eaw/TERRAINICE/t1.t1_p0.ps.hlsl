// ps_1_1 TERRAINICE::t1.t1_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d IceSampler : register(s0);
uniform sampler2d ReflectionSampler : register(s1);
uniform sampler2d FOWSampler : register(s2);

main {
    t0 = tex2D(IceSampler, in.TEXCOORD0);
    t1 = tex2D(ReflectionSampler, in.TEXCOORD1);
    t2 = tex2D(FOWSampler, in.TEXCOORD2);
    r0.xyz = 2 * (t0.xyz * in.COLOR0.xyz);
    r0.xyz = lerp(r0.xyz, t1.xyz, t0.www);
    r0.xyz = t2.xyz * r0.xyz;
    r0.w = 1;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
