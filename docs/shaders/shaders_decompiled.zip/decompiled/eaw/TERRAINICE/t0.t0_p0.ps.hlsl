// ps_2_0 TERRAINICE::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 IceDiffuse : register(c1);
uniform float IceReflectionDistortion : register(c2);
uniform sampler2d IceSampler : register(s0);
uniform sampler2d ReflectionSampler : register(s1);
uniform sampler2d FOWSampler : register(s2);
uniform sampler2d BumpSampler : register(s3);

// inputs: v0=COLOR0
main {
    r0 = tex2D(BumpSampler, in.TEXCOORD3);
    r0.xyz = r0.xyz + -0.5;
    r3.xyz = r0.xyz + r0.xyz;
    r0.xy = IceReflectionDistortion.xx * r3.xy + in.TEXCOORD1.xy;
    r2 = tex2D(ReflectionSampler, r0);
    r1 = tex2D(IceSampler, in.TEXCOORD0);
    r0 = tex2D(FOWSampler, in.TEXCOORD2);
    r4.xyz = in.TEXCOORD4.xyz + -0.5;
    r4.xyz = r4.xyz + r4.xyz;
    r3.x = saturate(dot(r3.xyz, r4.xyz));
    r3.xyz = r3.xxx * m_light0Diffuse.xyz;
    r3.xyz = r3.xyz * IceDiffuse.xyz + in.COLOR0.xyz;
    r3.xyz = r1.xyz * r3.xyz;
    r1.xyz = 2 * -r3.xyz + r2.xyz;
    r2.xyz = r3.xyz + r3.xyz;
    r1.xyz = r1.www * r1.xyz + r2.xyz;
    r0.xyz = r0.xyz * r1.xyz;
    r0.w = 1;
    out.COLOR0 = r0;
}
