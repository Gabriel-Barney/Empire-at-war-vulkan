// vs_1_1 PRIMDECALBUMPALPHA::particle_bump_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float4 m_eyePosObj : register(c4);
uniform float3 m_light0ObjVector : register(c5);
uniform float2 m_fogVals : register(c6);
uniform float2 m_distanceFadeVals : register(c7);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0, v3=COLOR0
main {
    r0.xyz = in.COLOR0.xyz + -0.5;
    r1.xyz = r0.xyz + r0.xyz;
    r0.xyz = r1.yzx * in.NORMAL0.zxy;
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r2.xyz = in.NORMAL0.yzx * r1.zxy + -r0.xyz;
    r3.y = dot(m_light0ObjVector.xyz, r2.xyz);
    r0.xyz = -in.POSITION0.xyz + m_eyePosObj.xyz;
    r3.z = dot(m_light0ObjVector.xyz, in.NORMAL0.xyz);
    r4.x = dot(r0.xyz, r0.xyz);
    r3.x = dot(m_light0ObjVector.xyz, r1.xyz);
    r0.w = rsqrt(r4.x);
    r4.x = dot(r3.xyz, r3.xyz);
    r0.xyz = r0.xyz * r0.www + m_light0ObjVector.xyz;
    r0.w = rsqrt(r4.x);
    r4.x = dot(r0.xyz, r0.xyz);
    r3.xyz = r3.xyz * r0.www;
    r0.w = rsqrt(r4.x);
    out.TEXCOORD2.xyz = r3.xyz * 0.5 + 0.5;
    r0.xyz = r0.xyz * r0.www;
    r1.x = dot(r0.xyz, r1.xyz);
    r1.y = dot(r0.xyz, r2.xyz);
    r1.z = dot(r0.xyz, in.NORMAL0.xyz);
    r0.x = dot(in.POSITION0, m_worldViewProj[0]);
    r0.y = dot(in.POSITION0, m_worldViewProj[1]);
    r0.z = dot(in.POSITION0, m_worldViewProj[2]);
    r3.x = dot(r1.xyz, r1.xyz);
    r2.x = dot(r0.xyz, r0.xyz);
    r1.w = rsqrt(r3.x);
    r0.w = rsqrt(r2.x);
    r1.xyz = r1.xyz * r1.www;
    r0.w = 1 / r0.w;
    out.TEXCOORD3.xyz = r1.xyz * 0.5 + 0.5;
    r1.w = m_distanceFadeVals.x * r0.w + m_distanceFadeVals.y;
    out.POSITION.xyz = r0.xyz;
    r1.w = max(r1.w, 0);
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    r1.w = min(r1.w, 1);
    out.COLOR0.w = r1.w * in.COLOR0.w;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR0.xyz = 1;
    out.COLOR1 = float4(0, 0, 0, 1);
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
}
