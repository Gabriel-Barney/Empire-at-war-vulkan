// ps_2_0 PRIMDECALBUMPALPHA::bump_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform sampler2d NormalSampler : register(s0);

// inputs: v0=COLOR0
main {
    r0 = tex2D(NormalSampler, in.TEXCOORD0);
    r0.xyz = r0.xyz + -0.5;
    r1.xyz = r0.xyz + r0.xyz;
    r0.xyz = in.TEXCOORD2.xyz + -0.5;
    r2.xyz = r0.xyz + r0.xyz;
    r0.x = saturate(dot(r1.xyz, r2.xyz));
    r1.w = 2 * -r0.z + r0.x;
    r0.w = r0.w * in.COLOR0.w;
    r0.xyz = r1.www * m_light0Diffuse.xyz;
    r0.xyz = r0.xyz * r0.www + 0.5;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;
}
