// ps_1_1 TERRAINFOGOFWAR::t1.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d FOWSampler : register(s0);

main {
    t0 = tex2D(FOWSampler, in.TEXCOORD0);
    r0 = t0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
