// vs_2_0 TERRAINFOGOFWAR::t0.t0_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float2 FilterSamples4[4] : register(c4);   // 4 regs
uniform float2 m_fogVals : register(c8);
uniform float4 m_FOWTexU : register(c9);
uniform float4 m_FOWTexV : register(c10);
uniform float2 FilterKernelSize : register(c11);

// inputs: v0=POSITION0
main {
    r0 = in.POSITION0.xyzx * float4(1, 1, 1, 0) + float4(0, 0, 0, 1);
    out.POSITION.w = dot(r0, m_worldViewProj[3]);
    r2.x = dot(m_FOWTexU, r0);
    r1.x = dot(r0, m_worldViewProj[0]);
    r1.y = dot(r0, m_worldViewProj[1]);
    r1.z = dot(r0, m_worldViewProj[2]);
    r2.y = dot(m_FOWTexV, r0);
    r3.x = dot(r1.xyz, r1.xyz);
    r0.xy = FilterKernelSize.xy;
    out.TEXCOORD0.xy = r0.xy * FilterSamples4[0].xy + r2.xy;
    r0.w = rsqrt(r3.x);
    out.TEXCOORD1.xy = r0.xy * FilterSamples4[1].xy + r2.xy;
    r0.w = 1 / r0.w;
    out.TEXCOORD2.xy = r0.xy * FilterSamples4[2].xy + r2.xy;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.TEXCOORD3.xy = r0.xy * FilterSamples4[3].xy + r2.xy;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
}
