// ps_2_0 TERRAINFOGOFWAR::t0.t0_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d FOWSampler : register(s0);

main {
    r0 = tex2D(FOWSampler, in.TEXCOORD0);
    r3 = tex2D(FOWSampler, in.TEXCOORD1);
    r2 = tex2D(FOWSampler, in.TEXCOORD2);
    r1 = tex2D(FOWSampler, in.TEXCOORD3);
    r0 = r0 + r3;
    r0 = r2 + r0;
    r0 = r1 + r0;
    r0 = r0 * 0.25;
    out.COLOR0 = r0;
}
