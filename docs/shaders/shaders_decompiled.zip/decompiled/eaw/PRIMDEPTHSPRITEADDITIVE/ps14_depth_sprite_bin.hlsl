// ps_1_4 PRIMDEPTHSPRITEADDITIVE::ps14_depth_sprite_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)

main {
    r1 = tex2D(sampler1, in.TEXCOORD0.xyz);
    r2.xyz = in.TEXCOORD1.xyz;
    r3.xyz = in.TEXCOORD2.xyz;
    r5.x = dot(r2.xyz, r1.xyz);
    r5.y = dot(r3.xyz, r1.xyz);
    // phase (ps_1_4: second texture-addressing phase)
    out.DEPTH = r5.x / r5.y;   // texdepth
    r0 = tex2D(sampler0, in.TEXCOORD0.xyz);
    r0 = r0 * in.COLOR0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
