// PRIMDEPTHSPRITEADDITIVE :: ps13_depth_sprite_bin  (sha1 9afae340849e)
ps_1_3
    tex t0
    tex t1
    texm3x2pad t2, t1
    texm3x2depth t3, t1
    mul r0, v0, t0
// 5 instruction slots used
