// ps_1_3 PRIMDEPTHSPRITEADDITIVE::ps13_depth_sprite_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)

main {
    t0 = tex2D(sampler0, in.TEXCOORD0);
    t1 = tex2D(sampler1, in.TEXCOORD1);
    t2 = dot(in.TEXCOORD2.xyz, t1.xyz)   // texm3x2pad: row of matrix;
    t3 = texm3x2depth(t1.xyz, in.TEXCOORD3)   // ps_1_x texture-addressing op;
    r0 = in.COLOR0 * t0;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
