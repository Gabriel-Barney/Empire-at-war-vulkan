// PRIMDEPTHSPRITEADDITIVE :: ps14_depth_sprite_bin  (sha1 4b76c082c386)
ps_1_4
    texld r1, t0
    texcrd r2.xyz, t1
    texcrd r3.xyz, t2
    dp3 r5.x, r2, r1
    dp3 r5.y, r3, r1
    phase
    texdepth r5
    texld r0, t0
    mul r0, r0, v0
// 8 instruction slots used
