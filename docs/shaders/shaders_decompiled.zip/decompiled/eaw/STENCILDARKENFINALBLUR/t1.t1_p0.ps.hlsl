// ps_2_0 STENCILDARKENFINALBLUR::t1.t1_p0.ps  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform sampler2d sampler0 : register(s0);
uniform sampler2d sampler1 : register(s1);
uniform sampler2d sampler2 : register(s2);
uniform sampler2d sampler3 : register(s3);

// inputs: v0=COLOR0
main {
    r2 = tex2D(sampler0, in.TEXCOORD0);
    r3 = tex2D(sampler1, in.TEXCOORD1);
    r1 = tex2D(sampler2, in.TEXCOORD2);
    r0 = tex2D(sampler3, in.TEXCOORD3);
    r2.w = r2.w + r3.w;
    r1.w = r1.w + r2.w;
    r0.w = r0.w + r1.w;
    r1.w = r0.w * 0.25;
    r0 = lerp(in.COLOR0, float4(1, 1, 1, 0), r1.wwww);
    out.COLOR0 = r0;
}
