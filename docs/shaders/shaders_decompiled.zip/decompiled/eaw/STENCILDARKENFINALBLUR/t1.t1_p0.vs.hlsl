// vs_1_1 STENCILDARKENFINALBLUR::t1.t1_p0.vs  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_worldViewProj : register(c0);   // 4 regs
uniform float2 samples4[4] : register(c4);   // 4 regs
uniform float blurAmt : register(c8);

// inputs: v0=POSITION0, v1=COLOR0, v2=TEXCOORD0
main {
    out.POSITION.x = dot(in.POSITION0, m_worldViewProj[0]);
    out.POSITION.y = dot(in.POSITION0, m_worldViewProj[1]);
    out.POSITION.z = dot(in.POSITION0, m_worldViewProj[2]);
    out.POSITION.w = dot(in.POSITION0, m_worldViewProj[3]);
    r0.w = blurAmt.x;
    out.TEXCOORD0.xy = r0.ww * samples4[0].xy + in.TEXCOORD0.xy;
    out.TEXCOORD1.xy = r0.ww * samples4[1].xy + in.TEXCOORD0.xy;
    out.TEXCOORD2.xy = r0.ww * samples4[2].xy + in.TEXCOORD0.xy;
    out.TEXCOORD3.xy = r0.ww * samples4[3].xy + in.TEXCOORD0.xy;
    out.COLOR0 = in.COLOR0.xyzx * float4(1, 1, 1, 0);
}
