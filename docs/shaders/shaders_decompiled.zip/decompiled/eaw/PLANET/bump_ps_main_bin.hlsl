// ps_1_4 PLANET::bump_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float3 Diffuse : register(c1);
uniform float4 Atmosphere : register(c2);
uniform float3 CityColor : register(c3);
uniform sampler2d NormalSampler : register(s0);
uniform sampler2d CloudSampler : register(s1);
uniform sampler2d BaseSampler : register(s2);

main {
    r0 = tex2D(NormalSampler, in.TEXCOORD1.xyz);
    r1.xyz = in.TEXCOORD3.xyz;
    r1.w = saturate(dot((2 * r0.xyz - 1), (2 * r1.xyz - 1)));
    r3.xyz = r1.www * Diffuse.xyz;
    r0.w = r0.w;
    r4.x = r0.w;
    // phase (ps_1_4: second texture-addressing phase)
    r0.xyz = in.TEXCOORD4.xyz;
    r1 = tex2D(CloudSampler, in.TEXCOORD2.xyz);
    r2 = tex2D(BaseSampler, in.TEXCOORD0.xyz);
    r4.w = r4.x;
    r3.xyz = r3.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r5.xyz = lerp(r2.xyz, r1.xyz, r1.www);
    r2.w = r2.w * r0.y;
    r0.xyz = r0.xxx * Atmosphere.xyz + r5.xyz;
    r1.w = r1.w * r2.w;
    r0.xyz = r3.xyz * r0.xyz;
    r0.xyz = r1.www * CityColor.xyz + (2 * r0.xyz);
    r0.xyz = r4.www * in.COLOR1.xyz + r0.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
