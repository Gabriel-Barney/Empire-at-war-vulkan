// ps_2_0 PLANET::bump_spec_ps_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float4 m_light0Specular : register(c1);
uniform float3 Diffuse : register(c2);
uniform float3 Specular : register(c3);
uniform float4 Atmosphere : register(c4);
uniform float3 CityColor : register(c5);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);
uniform sampler2d CloudSampler : register(s2);
uniform sampler2d CloudNormalSampler : register(s3);

// inputs: v0=COLOR0
main {
    r2 = tex2D(NormalSampler, in.TEXCOORD1);
    r3 = tex2D(BaseSampler, in.TEXCOORD0);
    r0 = tex2D(CloudSampler, in.TEXCOORD2);
    r1 = tex2D(CloudNormalSampler, in.TEXCOORD2);
    r4.xyz = in.TEXCOORD4.xyz + -0.5;
    r4.xyz = r4.xyz + r4.xyz;
    r2.xyz = r2.xyz + -0.5;
    r5.xyz = r2.xyz + r2.xyz;
    r2.x = saturate(dot(r5.xyz, r4.xyz));
    r1.w = pow(abs(r2.x), 16);
    r2.xyz = m_light0Specular.xyz;
    r2.xyz = r2.xyz * Specular.xyz;
    r2.xyz = r1.www * r2.xyz;
    r4.xyz = in.TEXCOORD3.xyz + -0.5;
    r4.xyz = r4.xyz + r4.xyz;
    r5.x = saturate(dot(r5.xyz, r4.xyz));
    r5.xyz = r5.xxx * Diffuse.xyz;
    r5.xyz = r5.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r3.xyz = Atmosphere.xyz * in.TEXCOORD5.xxx + r3.xyz;
    r1.w = r3.w * in.TEXCOORD5.y;
    r3.xyz = r5.xyz * r3.xyz;
    r3.w = -r0.w + 1;
    r3.xyz = r3.xyz + r3.xyz;
    r1.w = r1.w * r3.w;
    r3.xyz = r1.www * CityColor.xyz + r3.xyz;
    r2.xyz = r2.xyz * r2.www + r3.xyz;
    r1.xyz = r1.xyz + -0.5;
    r1.xyz = r1.xyz + r1.xyz;
    r1.x = saturate(dot(r1.xyz, r4.xyz));
    r0.xyz = r0.xyz * r1.xxx;
    r0.xyz = r0.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r0.xyz = 2 * r0.xyz + -r2.xyz;
    r0.xyz = r0.www * r0.xyz + r2.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;
}
