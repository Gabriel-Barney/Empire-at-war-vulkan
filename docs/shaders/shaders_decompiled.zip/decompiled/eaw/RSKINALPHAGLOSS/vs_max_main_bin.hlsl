// vs_1_1 RSKINALPHAGLOSS::vs_max_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x4 m_sphAll[3] : register(c72);   // 12 regs
uniform float4x4 m_viewProj : register(c84);   // 4 regs
uniform float4x4 m_world : register(c88);   // 3 regs
uniform float4 m_eyePos : register(c91);
uniform float4 m_light0Vector : register(c92);
uniform float4 m_light0Specular : register(c93);
uniform float4 m_lightScale : register(c94);
uniform float2 m_fogVals : register(c95);
uniform float3 Emissive : register(c96);
uniform float4 Diffuse : register(c97);
uniform float3 Specular : register(c98);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r1.x = dot(in.NORMAL0.xyz, m_world[0].xyz);
    r1.y = dot(in.NORMAL0.xyz, m_world[1].xyz);
    r1.z = dot(in.NORMAL0.xyz, m_world[2].xyz);
    r0.x = dot(r1.xyz, r1.xyz);
    r0.w = 1;
    r1.w = rsqrt(r0.x);
    r0.x = dot(in.POSITION0, m_world[0]);
    r1.xyz = r1.xyz * r1.www;
    r0.y = dot(in.POSITION0, m_world[1]);
    r2 = r1.yyyy * m_sphAll[1];
    r0.z = dot(in.POSITION0, m_world[2]);
    r2 = m_sphAll[0] * r1.xxxx + r2;
    out.POSITION.w = dot(r0, m_viewProj[3]);
    r2 = m_sphAll[2] * r1.zzzz + r2;
    r3 = r2 + m_sphAll[3];
    r2 = r1.yyyy * m_sphAll[5];
    r1.w = 1;
    r2 = m_sphAll[4] * r1.xxxx + r2;
    r4.x = dot(r1, r3);
    r2 = m_sphAll[6] * r1.zzzz + r2;
    r2 = r2 + m_sphAll[7];
    r3.xyz = -r0.xyz + m_eyePos.xyz;
    r4.y = dot(r1, r2);
    r5.x = dot(r3.xyz, r3.xyz);
    r2 = r1.yyyy * m_sphAll[9];
    r3.w = rsqrt(r5.x);
    r2 = m_sphAll[8] * r1.xxxx + r2;
    r3.xyz = r3.xyz * r3.www + m_light0Vector.xyz;
    r2 = m_sphAll[10] * r1.zzzz + r2;
    r5.x = dot(r3.xyz, r3.xyz);
    r2 = r2 + m_sphAll[11];
    r3.w = rsqrt(r5.x);
    r4.z = dot(r1, r2);
    r3.xyz = r3.xyz * r3.www;
    r2.xyz = r4.xyz * Diffuse.xyz;
    r3.x = dot(r1.xyz, r3.xyz);
    r1 = m_lightScale;
    out.COLOR0.xyz = r2.xyz * r1.xyz + Emissive.xyz;
    r2.w = max(r3.x, 0);
    out.COLOR0.w = r1.w * Diffuse.w;
    r1.w = r2.w * r2.w;
    r1.w = r1.w * r1.w;
    r1.x = dot(r0, m_viewProj[0]);
    r1.y = dot(r0, m_viewProj[1]);
    r1.z = dot(r0, m_viewProj[2]);
    r0.w = r1.w * r1.w;
    r0.x = dot(r1.xyz, r1.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r0.x);
    r0.xyz = r1.www * m_light0Specular.xyz;
    r0.w = 1 / r0.w;
    out.COLOR1.xyz = r0.xyz * Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.POSITION.xyz = r1.xyz;
    r0.w = max(r0.w, 0);
    out.FOG = min(r0.wwww, 1);
    out.COLOR1.w = 1;
    out.TEXCOORD0.xy = in.TEXCOORD0.xy;
    out.TEXCOORD1.xy = in.TEXCOORD0.xy;
}
