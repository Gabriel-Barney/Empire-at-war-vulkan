// vs_1_1 RSKINALPHAGLOSS::sph_vs_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4x3 m_skinMatrixArray[24] : register(c0);   // 72 regs
uniform float4x4 m_sphAll[3] : register(c72);   // 12 regs
uniform float4x4 m_viewProj : register(c84);   // 4 regs
uniform float4 m_eyePos : register(c88);
uniform float4 m_light0Vector : register(c89);
uniform float4 m_light0Specular : register(c90);
uniform float4 m_lightScale : register(c91);
uniform float2 m_fogVals : register(c92);
uniform float3 Emissive : register(c93);
uniform float4 Diffuse : register(c94);
uniform float3 Specular : register(c95);

// inputs: v0=POSITION0, v1=NORMAL0, v2=TEXCOORD0
main {
    r0.w = (in.NORMAL0.w < -in.NORMAL0.w) ? 1 : 0;
    r6.y = frac(in.NORMAL0.w);
    r1.w = r6.y;
    r2.w = -r1.w + in.NORMAL0.w;
    r1.w = (-r1.w < r1.w) ? 1 : 0;
    r0.w = r0.w * r1.w + r2.w;
    r1.w = r0.w * 3;
    a0.x = (int)r1.w;   // vs_1_1 mov to a0 truncates toward zero
    r1.x = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x].xyz);
    r1.y = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 1].xyz);
    r1.z = dot(in.NORMAL0.xyz, m_skinMatrixArray.reg[a0.x + 2].xyz);
    r0.x = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x]);
    r2.x = dot(r1.xyz, r1.xyz);
    r0.y = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 1]);
    r0.w = rsqrt(r2.x);
    r0.z = dot(in.POSITION0, m_skinMatrixArray.reg[a0.x + 2]);
    r2.xyz = r1.xyz * r0.www;
    r0.w = 1;
    r1 = r2.yyyy * m_sphAll[1];
    out.POSITION.w = dot(r0, m_viewProj[3]);
    r1 = m_sphAll[0] * r2.xxxx + r1;
    r3 = m_sphAll[2] * r2.zzzz + r1;
    r1 = r2.yyyy * m_sphAll[5];
    r3 = r3 + m_sphAll[3];
    r1 = m_sphAll[4] * r2.xxxx + r1;
    r2.w = 1;
    r1 = m_sphAll[6] * r2.zzzz + r1;
    r4.x = dot(r2, r3);
    r1 = r1 + m_sphAll[7];
    r4.y = dot(r2, r1);
    r3.xyz = -r0.xyz + m_eyePos.xyz;
    r1 = r2.yyyy * m_sphAll[9];
    r5.x = dot(r3.xyz, r3.xyz);
    r1 = m_sphAll[8] * r2.xxxx + r1;
    r3.w = rsqrt(r5.x);
    r1 = m_sphAll[10] * r2.zzzz + r1;
    r3.xyz = r3.xyz * r3.www + m_light0Vector.xyz;
    r1 = r1 + m_sphAll[11];
    r5.x = dot(r3.xyz, r3.xyz);
    r4.z = dot(r2, r1);
    r1.w = rsqrt(r5.x);
    r4.xyz = r4.xyz * Diffuse.xyz;
    r3.xyz = r3.xyz * r1.www;
    r1 = m_lightScale;
    out.COLOR0.xyz = r4.xyz * r1.xyz + Emissive.xyz;
    r1.x = dot(r2.xyz, r3.xyz);
    out.COLOR0.w = r1.w * Diffuse.w;
    r1.w = max(r1.x, 0);
    r1.w = r1.w * r1.w;
    r1.x = dot(r0, m_viewProj[0]);
    r1.y = dot(r0, m_viewProj[1]);
    r1.z = dot(r0, m_viewProj[2]);
    r0.w = r1.w * r1.w;
    r0.x = dot(r1.xyz, r1.xyz);
    r1.w = r0.w * r0.w;
    r0.w = rsqrt(r0.x);
    r1.w = r1.w * r1.w;
    r0.w = 1 / r0.w;
    r0.xyz = r1.www * m_light0Specular.xyz;
    r0.w = m_fogVals.x * r0.w + m_fogVals.y;
    out.COLOR1.xyz = r0.xyz * Specular.xyz;
    r0.w = max(r0.w, 0);
    out.POSITION.xyz = r1.xyz;
    out.FOG = min(r0.wwww, 1);
    out.COLOR1.w = 1;
    r0.xy = in.TEXCOORD0.xy * 0.0002441406;
    out.TEXCOORD0.xy = r0.xy;
    out.TEXCOORD1.xy = r0.xy;
}
