// ps_1_1 MESHBUMPREFLECTCOLORIZE::bump_reflect_colorize_ps11_main_bin  (lifted pseudocode; register-faithful, not verbatim HLSL)
// uniforms (CTAB):
uniform float4 m_light0Diffuse : register(c0);
uniform float3 Diffuse : register(c1);
uniform float3 Specular : register(c2);
uniform float4 Colorization : register(c3);
uniform sampler2d BaseSampler : register(s0);
uniform sampler2d NormalSampler : register(s1);
uniform samplercube SkyCubeSampler : register(s3);

main {
    t0 = tex2D(BaseSampler, in.TEXCOORD0);
    t1 = tex2D(NormalSampler, in.TEXCOORD1);
    t2 = saturate(float4(in.TEXCOORD2.xyz, 1));
    t3 = tex2D(SkyCubeSampler, in.TEXCOORD3);
    r0.xyz = t0.xyz * Colorization.xyz;
    r0.xyz = lerp(t0.xyz, r0.xyz, t0.www);
    r1.xyz = saturate(dot((2 * t1.xyz - 1), (2 * t2.xyz - 1)));
    r1.xyz = r1.xyz * Diffuse.xyz;
    r1.xyz = r1.xyz * m_light0Diffuse.xyz + in.COLOR0.xyz;
    r0.xyz = 2 * (r0.xyz * r1.xyz);
    r1.xyz = t3.xyz * Specular.xyz;
    r0.xyz = t1.www * r1.xyz + r0.xyz;
    r0.w = in.COLOR0.w;
    out.COLOR0 = r0;   // ps_1_x: r0 is the output color
}
